import re
from typing import Sequence

PROMPT_INJECTION_PATTERNS = [
    re.compile(r"ignore (?:previous|above|all|prior|your) (?:instructions|prompts|rules)", re.IGNORECASE),
    re.compile(r"you are now|act as|pretend you|new instructions|forget (?:your|all|previous)", re.IGNORECASE),
    re.compile(r"system\s*prompt|<\s*/?\s*(?:system|instruction|prompt)\s*>", re.IGNORECASE),
]

COMMAND_INJECTION_PATTERNS = [
    re.compile(r"^\s*!", re.MULTILINE),
    re.compile(r"^\s*(?:sudo|chmod|chown|rm\s|mv\s|cp\s|curl\s|wget\s|apt|yum|brew|pip\s|npm\s)", re.MULTILINE | re.IGNORECASE),
    re.compile(r"(?:&&|\|\||;)\s*(?:ls|cat|rm|curl|wget|chmod|sudo)", re.IGNORECASE),
    re.compile(r"\bexec\s*\(|\beval\s*\(|\bos\.system\s*\(|\bsubprocess\b", re.IGNORECASE),
    re.compile(r"`[^`]*(?:rm|curl|wget|sudo|chmod)[^`]*`"),
]

DEFAULT_PATTERNS = PROMPT_INJECTION_PATTERNS + COMMAND_INJECTION_PATTERNS


def detect_injection(text: str, patterns: Sequence[re.Pattern] | None = None) -> bool:
    for p in (patterns or DEFAULT_PATTERNS):
        if p.search(text):
            return True
    return False
