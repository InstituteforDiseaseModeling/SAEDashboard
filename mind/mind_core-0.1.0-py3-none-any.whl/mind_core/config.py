from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from mind_core.session import Session, SessionStore
    from mind_core.types import ToolResult


def _resolve(value: Any, session: "Session") -> Any:
    return value(session) if callable(value) else value


@dataclass
class MindConfig:
    """All settings for the mind agent. A dashboard creates one and passes it to create_app()."""
    model: str = "claude-sonnet-4-6"
    max_tokens: int = 8192
    api_key: str | None = None
    api_base: str | None = None

    system_prompt: str | list[dict] | Callable[["Session"], str | list[dict]] = ""
    system_prompt_suffix: str = ""  # appended to system_prompt for per-deployment customization  # [MIND-CORE-IMPROVEMENT]

    tool_schemas: list[dict] | Callable[["Session"], list[dict]] = field(default_factory=list)
    tool_dispatch: dict[str, Callable] | Callable[["Session"], dict[str, Callable]] = field(default_factory=dict)

    pre_message_hook: Callable[[str, "Session"], str | None] | None = None  # called before each user message; return str to replace it, None to keep  # [MIND-CORE-IMPROVEMENT]
    post_tool_hook: Callable[[str, "ToolResult", dict, "Session"], None] | None = None  # called after each tool execution with (tool_name, result, input, session)  # [MIND-CORE-IMPROVEMENT]
    request_hook: Callable[[dict, "Session"], None] | None = None  # called with the full API request dict before sending to Anthropic  # [MIND-CORE-IMPROVEMENT]
    title_generator: Callable[[str, "Session"], str] | None = None  # generates a session title from the first user message  # [MIND-CORE-IMPROVEMENT]
    progress_message: Callable[[str, dict], str] | None = None  # returns a user-facing progress string from (tool_name, tool_input)  # [MIND-CORE-IMPROVEMENT]

    session_store: Any = None  # SessionStore — Any to avoid circular import at class def time
    default_session_mode: str = "default"
    session_filter: Callable[["Session"], bool] | None = None

    file_saved_prefix: str = "/data/tmp"  # URL prefix for files saved by tools, used to build download links  # [MIND-CORE-IMPROVEMENT]

    max_iterations: int = 30
    model_budgets: dict[str, int] = field(default_factory=lambda: {  # per-model token budget caps  # [MIND-CORE-IMPROVEMENT]
        "claude-opus-4-6": 180_000,
        "claude-sonnet-4-6": 180_000,
        "claude-haiku-4-5-20251001": 180_000,
    })
    default_budget: int = 80_000  # token budget for models not listed in model_budgets  # [MIND-CORE-IMPROVEMENT]
    data_dir: str = "/data"

    python_timeout: int = 120  # [MIND-CORE-IMPROVEMENT] timeout in seconds for execute_python subprocess
    bash_timeout: int = 30  # [MIND-CORE-IMPROVEMENT] timeout in seconds for bash_cmd subprocess
    cors_origins: list[str] = field(default_factory=lambda: ["*"])  # [MIND-CORE-IMPROVEMENT] allowed CORS origins

    def __post_init__(self):
        if self.session_store is None:
            from mind_core.session import InMemorySessionStore
            self.session_store = InMemorySessionStore()
