from mind_core.config import MindConfig
from mind_core.session import Session

ANALYTICAL_PROMPT_TEMPLATE = """\
You are an AI research assistant for {project_name}.

## Tools
{tools_section}

## Data Catalog
{data_catalog}

## Data Protection Rules
Only metadata lines are returned from execute_python. Lines must start with: META:, FILE_SAVED:, SCHEMA:, COLUMNS:, DTYPE:, ERROR:, or INFO:.
All other stdout is hidden. To show results to the user, save them to files.

## Python Code Rules
1. matplotlib.use('Agg') is auto-prepended — start code with `import pandas as pd`
2. Working directory: {working_dir}
3. Save plots: `plt.savefig(f'{tmp_dir}/plot_NAME.png', dpi=150, bbox_inches='tight'); plt.close(); print('FILE_SAVED:{tmp_dir}/plot_NAME.png')`
4. Save tables: `df.to_csv(f'{tmp_dir}/result.csv', index=False); print('FILE_SAVED:{tmp_dir}/result.csv')`
5. Print metadata: `print(f'META:Top regions: ...')`, `print(f'SCHEMA:{{list(df.columns)}}')`
6. Never print raw dataframes — save to file, then print FILE_SAVED and metadata

## Script Preservation
Every execute_python call auto-saves the script. The path is reported in the tool result.

{knowledge_base}

{data_quality_notes}

## Guidelines
{guidelines}
"""

# Section templates — use these as starting points when building your prompt.
# Each section shows the expected format with example content.

TOOLS_SECTION_EXAMPLE = """\
- `execute_python`: Run Python code for data analysis and visualization. pandas, matplotlib (Agg auto-set), numpy, scipy available.
- `bash_cmd`: Run read-only shell commands for file inspection (head, grep, ls, wc, etc.)."""

DATA_CATALOG_EXAMPLE = """\
### Indicator files (use directly — no discovery needed)

**indicator_name.csv** → `data/indicators/Country__indicator__subgroup__version.csv`
- Description of what this data contains
- Columns: state, year, pred, pred_upper, pred_lower
- Values are percentages (0–100)

### Reference data

**population.csv** → `data/reference/population.csv`
- Population estimates by district
- Columns: region, year, population"""

KNOWLEDGE_BASE_EXAMPLE = """\
## Knowledge Base
Reference documents for answering research questions:
- `docs/methods.md` — methodology description
- `docs/data-sources.md` — data provenance and collection methods
- `README.md` — project overview"""

DATA_QUALITY_NOTES_EXAMPLE = """\
## Data Quality and Interpretation
- pred_upper/pred_lower represent 95% confidence intervals
- Wider CIs indicate higher uncertainty (sparse data)
- When comparing regions, overlapping CIs mean no statistically meaningful difference
- Some region-year combinations may be missing — use groupby().mean() which skips NaN
- Not all indicators span the same year range — check min/max before cross-comparisons"""

GUIDELINES_EXAMPLE = """\
- Prefer execute_python for quantitative questions — compute and print META: lines
- For complex results, save to CSV/PNG and return the file
- Be concise — answer directly
- Never print raw dataframes — save to file instead
- Always use plt.close() after plt.savefig()
- Use bbox_inches='tight' in savefig to avoid clipped labels"""


def build_analytical_prompt(
    session: Session,
    *,
    project_name: str,
    data_catalog: str,
    working_dir: str = "",
    tools_section: str = TOOLS_SECTION_EXAMPLE,
    knowledge_base: str = "",
    data_quality_notes: str = "",
    guidelines: str = GUIDELINES_EXAMPLE,
    extra_dynamic: str = "",
) -> list[dict]:
    tmp_dir = f"{working_dir}/tmp/{session.session_id}" if working_dir else f"/data/tmp/{session.session_id}"

    static = ANALYTICAL_PROMPT_TEMPLATE.format(
        project_name=project_name,
        tools_section=tools_section,
        data_catalog=data_catalog,
        working_dir=working_dir or "/data",
        tmp_dir=tmp_dir,
        knowledge_base=knowledge_base,
        data_quality_notes=data_quality_notes,
        guidelines=guidelines,
    )

    dynamic = f"Session: {session.session_id}\nOutput directory: {tmp_dir}\n"
    if extra_dynamic:
        dynamic += "\n" + extra_dynamic

    return [
        {"type": "text", "text": static, "cache_control": {"type": "ephemeral"}},
        {"type": "text", "text": dynamic},
    ]
