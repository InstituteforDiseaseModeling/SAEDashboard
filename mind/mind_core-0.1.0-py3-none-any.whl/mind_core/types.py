from dataclasses import dataclass, field


@dataclass
class ToolResult:
    output: str
    files: list[str] = field(default_factory=list)
