import asyncio
import json
import logging
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict

from mind_core.storage.atomic import atomic_write_json

logger = logging.getLogger(__name__)


class Session(BaseModel):
    model_config = ConfigDict(extra="ignore")
    session_id: str
    mode: str = "default"
    context: dict = {}
    messages: list[dict] = []
    created_at: str = ""
    updated_at: str = ""
    title: str = ""
    current_model: str = ""


@runtime_checkable
class SessionStore(Protocol):
    def get(self, session_id: str) -> Session | None: ...
    def save(self, session: Session) -> None: ...
    def delete(self, session_id: str) -> None: ...
    def list_all(self) -> list[Session]: ...


class InMemorySessionStore:
    def __init__(self):
        self._sessions: dict[str, Session] = {}

    def get(self, session_id: str) -> Session | None:
        return self._sessions.get(session_id)

    def save(self, session: Session) -> None:
        session.updated_at = datetime.now(timezone.utc).isoformat()
        self._sessions[session.session_id] = session

    def delete(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)

    def list_all(self) -> list[Session]:
        return list(self._sessions.values())


class FileSessionStore:
    def __init__(self, base_dir: Path, data_dir: str = "/data"):
        self._base_dir = base_dir
        self._data_dir = Path(data_dir)
        self._cache: dict[str, Session] = {}

    def get(self, session_id: str) -> Session | None:
        if session_id in self._cache:
            return self._cache[session_id]
        for subdir in self._iter_subdirs():
            p = subdir / f"{session_id}.json"
            if p.exists():
                try:
                    s = Session(**json.loads(p.read_text()))
                    self._cache[session_id] = s
                    return s
                except json.JSONDecodeError:  # [MIND-CORE-IMPROVEMENT] distinguish corruption from other errors
                    logger.warning("Corrupt session file, skipping: %s", p)
                except Exception:  # [MIND-CORE-IMPROVEMENT]
                    logger.warning("Failed to load session file: %s", p, exc_info=True)
        return None

    def save(self, session: Session) -> None:
        session.updated_at = datetime.now(timezone.utc).isoformat()
        path = self._session_path(session)
        atomic_write_json(path, session.model_dump())
        self._cache[session.session_id] = session
        for subdir in self._iter_subdirs():
            if subdir.name != session.mode:
                old = subdir / f"{session.session_id}.json"
                if old.exists():
                    old.unlink()

    def delete(self, session_id: str) -> None:
        self._cache.pop(session_id, None)
        for subdir in self._iter_subdirs():
            p = subdir / f"{session_id}.json"
            if p.exists():
                p.unlink()
        for d in [self._data_dir / "tmp" / session_id, self._data_dir / "uploads" / session_id]:
            if d.exists():
                shutil.rmtree(d, ignore_errors=True)

    def list_all(self) -> list[Session]:
        return list(self._cache.values())

    def rehydrate(self) -> None:
        self._base_dir.mkdir(parents=True, exist_ok=True)
        for subdir in self._iter_subdirs():
            for p in subdir.glob("*.json"):
                if p.stem in self._cache:
                    continue
                try:
                    s = Session(**json.loads(p.read_text()))
                    self._cache[s.session_id] = s
                except json.JSONDecodeError:  # [MIND-CORE-IMPROVEMENT] distinguish corruption from other errors
                    logger.warning("Corrupt session file during rehydrate, skipping: %s", p)
                except Exception:  # [MIND-CORE-IMPROVEMENT]
                    logger.warning("Failed to rehydrate session file: %s", p, exc_info=True)

    def _session_path(self, session: Session) -> Path:
        return self._base_dir / session.mode / f"{session.session_id}.json"

    def _iter_subdirs(self):
        if not self._base_dir.exists():
            return
        for p in self._base_dir.iterdir():
            if p.is_dir():
                yield p


_session_locks: dict[str, asyncio.Lock] = {}


def get_lock(session_id: str) -> asyncio.Lock:
    if session_id not in _session_locks:
        _session_locks[session_id] = asyncio.Lock()
    return _session_locks[session_id]


def get_or_create_session(store: SessionStore, session_id: str, mode: str = "default") -> Session:
    s = store.get(session_id)
    if s:
        return s
    s = Session(session_id=session_id, mode=mode, created_at=datetime.now(timezone.utc).isoformat())
    store.save(s)
    return s


def clean_messages(messages: list[dict]) -> list[dict]:
    out = []
    for msg in messages:
        if msg["role"] == "user":
            content = msg.get("content", "")
            if isinstance(content, str) and content.strip():
                out.append({"role": "user", "content": content})
        elif msg["role"] == "assistant":
            content = msg.get("content") or ""
            if content.strip():
                text = re.sub(r'<form>.*?</form>', '', content, flags=re.DOTALL).strip()
                if text:
                    entry = {"role": "assistant", "content": text}
                    if msg.get("files"):
                        entry["files"] = msg["files"]
                    if msg.get("resources"):
                        entry["resources"] = msg["resources"]
                    out.append(entry)
    return out


def _last_model(session: Session) -> str | None:
    for msg in reversed(session.messages):
        if msg.get("model"):
            return msg["model"]
    return None
