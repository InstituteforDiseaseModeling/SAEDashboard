from fastapi import APIRouter, HTTPException

from mind_core.config import MindConfig
from mind_core.session import _last_model, clean_messages


def create_sessions_router(config: MindConfig) -> APIRouter:
    router = APIRouter()

    @router.get("/sessions")
    def list_sessions(mode: str | None = None):
        result = []
        for s in config.session_store.list_all():
            if mode and s.mode != mode:
                continue
            if config.session_filter and not config.session_filter(s):
                continue
            result.append({
                "session_id": s.session_id,
                "mode": s.mode,
                "title": s.title or f"{len(s.messages)} messages",
                "created_at": s.created_at,
                "updated_at": s.updated_at,
                "last_model": _last_model(s),
                "message_count": len(s.messages),
            })
        result.sort(key=lambda x: x["updated_at"] or "", reverse=True)
        return {"sessions": result}

    @router.get("/sessions/{session_id}/messages")
    def get_session_messages(session_id: str):
        s = config.session_store.get(session_id)
        if not s:
            raise HTTPException(status_code=404, detail="Session not found")
        return {"session_id": s.session_id, "mode": s.mode, "messages": clean_messages(s.messages)}

    @router.delete("/sessions/{session_id}")
    def delete_session(session_id: str):
        config.session_store.delete(session_id)
        return {"deleted": session_id}

    return router
