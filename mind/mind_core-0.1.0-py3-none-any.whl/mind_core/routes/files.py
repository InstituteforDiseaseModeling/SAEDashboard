from pathlib import Path

from fastapi import APIRouter
from fastapi.responses import FileResponse, PlainTextResponse

from mind_core.config import MindConfig


def create_files_router(config: MindConfig) -> APIRouter:
    router = APIRouter()

    @router.get("/files/{session_id}/{filename}")
    async def serve_file(session_id: str, filename: str):
        path = Path(config.data_dir) / "tmp" / session_id / filename
        if not path.exists():
            return PlainTextResponse("File not found", status_code=404)
        return FileResponse(path, filename=filename)

    @router.get("/files/{session_id}/{filename}/raw")
    async def serve_file_raw(session_id: str, filename: str):
        path = Path(config.data_dir) / "tmp" / session_id / filename
        if not path.exists():
            return PlainTextResponse("File not found", status_code=404)
        return PlainTextResponse(path.read_text())

    return router
