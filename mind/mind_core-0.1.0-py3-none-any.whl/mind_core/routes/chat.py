import uuid

from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse
from starlette.concurrency import iterate_in_threadpool

from mind_core.agent import run_agent_stream
from mind_core.config import MindConfig
from mind_core.session import get_or_create_session


def create_chat_router(config: MindConfig) -> APIRouter:
    router = APIRouter()

    @router.post("/chat")
    async def chat(request: Request):
        data = await request.json()
        session_id = data.get("session_id") or str(uuid.uuid4())
        message = data["message"]
        api_key = data.get("api_key")

        if isinstance(message, dict):
            form_id = message.get("form_id", "unknown")
            formatted = f"[Form submission: {form_id}]\n"
            for k, v in message.get("values", {}).items():
                formatted += f"- {k}: {v}\n"
            message = formatted

        session = get_or_create_session(config.session_store, session_id, mode=config.default_session_mode)

        if config.request_hook:
            config.request_hook(data, session)

        gen = run_agent_stream(config, session, message, api_key)
        return StreamingResponse(
            iterate_in_threadpool(gen),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    return router
