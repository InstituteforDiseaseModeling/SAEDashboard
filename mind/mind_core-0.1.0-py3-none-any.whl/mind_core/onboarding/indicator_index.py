import logging
from pathlib import Path

import pandas as pd

from mind_core.onboarding.metadata_store import list_indicators

logger = logging.getLogger(__name__)

_cached_index: str | None = None
_cached_mtime: float = 0.0


def invalidate_index():
    global _cached_index, _cached_mtime
    _cached_index = None
    _cached_mtime = 0.0


def _build_entry(ind, indicators_dir: Path) -> str:
    parts = [f"- **{ind.id}** ({ind.display_name})"]
    if ind.description:
        parts[0] += f": {ind.description[:120]}"

    details = [f"country={ind.country}", f"subgroups={ind.subgroups}"]
    first_file = next((indicators_dir / f for f in ind.csv_files if (indicators_dir / f).exists()), None)
    if first_file:
        try:
            df = pd.read_csv(first_file, nrows=5)
            cols = list(df.columns)
            details.append(f"columns={cols}")
            if "year" in df.columns:
                full = pd.read_csv(first_file, usecols=["year", "state"])
                details.append(f"years={int(full['year'].min())}-{int(full['year'].max())}")
                details.append(f"regions={full['state'].nunique()}")
        except Exception as e:
            logger.debug("index scan %s: %s", first_file.name, e)

    details.append(f"files={ind.csv_files}")
    parts.append(f"  {', '.join(details)}")
    return "\n".join(parts)


def build_index(metadata_path: Path, indicators_dir: Path) -> str:
    indicators = list_indicators(metadata_path)
    if not indicators:
        return "(no indicators registered yet)"
    entries = []
    for ind in indicators:
        all_countries = {f.split("__")[0] for f in ind.csv_files if "__" in f}
        if all_countries and all_countries <= set(ind.hidden_countries):
            continue
        entries.append(_build_entry(ind, indicators_dir))
    return "\n".join(entries) if entries else "(no indicators registered yet)"


def _dir_mtime(metadata_dir: Path) -> float:
    try:
        return max((f.stat().st_mtime for f in metadata_dir.glob("*.json")), default=0.0)
    except OSError:
        return 0.0


def get_cached_index(metadata_path: Path, indicators_dir: Path) -> str:
    global _cached_index, _cached_mtime
    current_mtime = _dir_mtime(metadata_path)

    if _cached_index is not None and current_mtime == _cached_mtime:
        return _cached_index

    _cached_index = build_index(metadata_path, indicators_dir)
    _cached_mtime = current_mtime
    return _cached_index
