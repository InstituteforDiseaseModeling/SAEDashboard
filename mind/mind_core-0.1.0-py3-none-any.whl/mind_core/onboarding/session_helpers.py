from mind_core.session import Session, SessionStore


def start_onboarding(session: Session, upload_id: str, creation_id: str,
                     source_kind: str = "new_upload"):
    session.context["onboarding"] = {
        "creation_id": creation_id,
        "upload_id": upload_id,
        "source_kind": source_kind,
        "user_instructions": None,
    }
    session.mode = "onboarding"


def end_onboarding(session: Session, indicator_id: str, target_mode: str = "analytical"):
    session.context.pop("onboarding", None)
    session.context["indicator_id"] = indicator_id
    session.mode = target_mode


def get_onboarding_context(session: Session) -> dict | None:
    return session.context.get("onboarding")


def get_upload_id(session: Session) -> str | None:
    ctx = get_onboarding_context(session)
    return ctx.get("upload_id") if ctx else None


def get_indicator_id(session: Session) -> str | None:
    return session.context.get("indicator_id")


def find_onboarding_session(store: SessionStore, indicator_id: str) -> Session | None:
    for s in store.list_all():
        if s.context.get("indicator_id") == indicator_id:
            return s
    return None
