def onboarding_progress_message(tool_name: str, tool_input: dict) -> str:
    msgs = {
        "validate_upload": "Validating uploaded file...",
        "preview_data": "Analyzing data...",
        "transform_csv": "Transforming data...",
        "list_existing_indicators": "Checking existing indicators...",
        "detect_shape_version": "Detecting map boundary version...",
        "finalize_indicator": "Finalizing indicator...",
        "batch_finalize_indicator": "Creating indicator with multiple subgroups...",
        "execute_python": tool_input.get("description", "Running analysis...")[:80],
    }
    return msgs.get(tool_name, f"Using {tool_name}...")
