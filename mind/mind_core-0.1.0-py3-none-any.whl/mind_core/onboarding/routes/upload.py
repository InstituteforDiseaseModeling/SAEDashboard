import uuid

from fastapi import APIRouter, UploadFile, File

from mind_core.config import MindConfig
from mind_core.onboarding.config import OnboardingConfig
from mind_core.onboarding.csv_validator import load_upload
from mind_core.onboarding.session_helpers import start_onboarding
from mind_core.onboarding.uploads_store import Upload, save_upload
from mind_core.session import get_or_create_session


def create_onboarding_upload_router(config: MindConfig, ob_config: OnboardingConfig) -> APIRouter:
    router = APIRouter()

    @router.post("/upload")
    async def upload_file(file: UploadFile = File(...)):
        session_id = str(uuid.uuid4())[:8]
        upload_dir = ob_config.uploads_dir / session_id
        upload_dir.mkdir(parents=True, exist_ok=True)

        file_path = upload_dir / file.filename
        content = await file.read()
        file_path.write_bytes(content)

        save_upload(ob_config.uploads_dir, Upload(
            upload_id=session_id, filename=file.filename,
            stored_path=str(file_path), size=len(content),
        ))

        session = get_or_create_session(config.session_store, session_id, mode="onboarding")
        start_onboarding(session, session_id, session_id)
        config.session_store.save(session)

        try:
            df, info = load_upload(file_path)
            sample_rows = df.head(5).fillna("").to_dict(orient="records")
        except Exception as e:
            return {
                "session_id": session_id, "filename": file.filename,
                "validation": {"columns": [], "row_count": 0, "issues": [str(e)], "file_type": file_path.suffix},
                "sample_rows": [],
            }

        return {
            "session_id": session_id, "filename": file.filename,
            "validation": {
                "columns": info["columns"], "row_count": info["row_count"],
                "file_type": info["file_type"], "sheets": info.get("sheets"), "issues": [],
            },
            "sample_rows": sample_rows,
        }

    return router
