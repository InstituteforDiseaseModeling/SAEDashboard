import io
import json
import logging
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import StreamingResponse

import pandas as pd

from mind_core.config import MindConfig
from mind_core.onboarding.config import OnboardingConfig
from mind_core.onboarding.metadata_store import (
    list_indicators, get_indicator, update_indicator, delete_indicator,
    remove_country_from_indicator, toggle_country_hidden,
)
from mind_core.onboarding.session_helpers import find_onboarding_session
from mind_core.session import clean_messages

logger = logging.getLogger(__name__)

from mind_core.onboarding.constants import DATA_FILE_REGEX  # [MIND-CORE-IMPROVEMENT] deduplicated


def _scan_indicator_files(indicators_dir: Path) -> dict[tuple[str, str], dict]:
    if not indicators_dir.exists():
        return {}
    indicators = {}
    for f in indicators_dir.glob("*.csv"):
        m = DATA_FILE_REGEX.match(f.name)
        if not m:
            continue
        key = (m["country"], m["channel"])
        if key not in indicators:
            indicators[key] = {"id": m["channel"], "country": m["country"], "subgroups": [], "version": m["version"], "csv_files": []}
        indicators[key]["subgroups"].append(m["subgroup"])
        indicators[key]["csv_files"].append(f.name)
    return indicators


def _get_indicator_data_meta(indicators_dir: Path, channel: str, country: str, subgroup: str, version: str) -> dict:
    filename = f"{country}__{channel}__{subgroup}__{version}.csv"
    path = indicators_dir / filename
    if not path.exists():
        return {"admin_levels": [], "time": {}}
    df = pd.read_csv(path)
    admin_levels = set()
    if "state" in df.columns:
        admin_levels = {int(x) for x in (df["state"].str.count(":")).unique()}
    time_data = {}
    if "year" in df.columns:
        for year in sorted(df["year"].unique()):
            time_data[int(year)] = []
    return {"admin_levels": sorted(admin_levels), "time": time_data}


def create_indicators_router(config: MindConfig, ob_config: OnboardingConfig) -> APIRouter:
    router = APIRouter()
    indicators_dir = ob_config.indicators_dir
    metadata_path = ob_config.metadata_path

    @router.get("/indicators")
    async def get_indicators():
        file_indicators = _scan_indicator_files(indicators_dir)
        metadata = {m.id: m for m in list_indicators(metadata_path)}
        result = []
        for (country_key, ind_id), file_info in file_indicators.items():
            meta = metadata.get(ind_id)
            first_subgroup = file_info["subgroups"][0] if file_info["subgroups"] else "all"
            data_meta = _get_indicator_data_meta(indicators_dir, ind_id, file_info["country"], first_subgroup, file_info["version"])
            result.append({
                "id": ind_id,
                "display_name": meta.display_name if meta else ind_id.replace("_", " ").title(),
                "description": meta.description if meta else "",
                "country": file_info["country"],
                "subgroups": sorted(set(file_info["subgroups"]) | {"all"}),
                "version": file_info["version"],
                "color_theme": meta.color_theme if meta else "RdBu",
                "hidden": (country_key in meta.hidden_countries) if meta else False,
                "is_user_created": True,
                "created_at": meta.created_at if meta else "",
                "onboarding_notes": meta.onboarding_notes if meta else "",
                "admin_levels": data_meta["admin_levels"],
                "time": data_meta["time"],
            })
        result.sort(key=lambda r: (r["id"], r["country"]))
        return {"indicators": result}

    @router.patch("/indicators/{indicator_id}")
    async def patch_indicator(indicator_id: str, body: dict, country: str = Query(...)):
        meta = get_indicator(metadata_path, indicator_id)
        if not meta:
            raise HTTPException(404, "Indicator not found")
        if "hidden" in body:
            hide = bool(body["hidden"])
            updated = toggle_country_hidden(metadata_path, indicator_id, country, hide)
            if not updated:
                raise HTTPException(500, "Update failed")
            country_prefix = f"{country}__"
            if hide and ob_config.deregister_indicator:
                try:
                    ob_config.deregister_indicator(indicator_id, False, country=country)
                except Exception:
                    logger.warning("Failed to deregister %s for %s", indicator_id, country, exc_info=True)
            elif not hide and ob_config.register_indicator:
                for csv_file in updated.csv_files:
                    if csv_file.startswith(country_prefix):
                        path = indicators_dir / csv_file
                        if path.exists():
                            try:
                                ob_config.register_indicator(path, updated)
                            except Exception:
                                logger.warning("Failed to register %s", csv_file, exc_info=True)
            return {"ok": True, "hidden": hide}
        return {"ok": True}

    @router.get("/indicators/{indicator_id}/chat")
    async def get_indicator_chat(indicator_id: str):
        session = find_onboarding_session(config.session_store, indicator_id)
        if session:
            return {"messages": clean_messages(session.messages)}
        return {"messages": []}

    @router.get("/indicators/{indicator_id}/download")
    async def download_indicator(indicator_id: str):
        meta = get_indicator(metadata_path, indicator_id)
        csv_files = sorted(indicators_dir.glob(f"*__{indicator_id}__*.csv"))
        if not meta and not csv_files:
            raise HTTPException(404, "Indicator not found")

        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            if meta:
                zf.writestr(f"{indicator_id}/metadata.json", json.dumps(meta.model_dump(), indent=2))
            for csv_path in csv_files:
                zf.write(csv_path, arcname=f"{indicator_id}/indicators/{csv_path.name}")
            ob_session = find_onboarding_session(config.session_store, indicator_id)
            if ob_session:
                zf.writestr(f"{indicator_id}/chat.json", json.dumps(clean_messages(ob_session.messages), indent=2))
        buf.seek(0)
        return StreamingResponse(
            buf, media_type="application/zip",
            headers={"Content-Disposition": f'attachment; filename="{indicator_id}.zip"'},
        )

    @router.get("/backup")
    async def download_backup():
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            all_meta = {m.id: m.model_dump() for m in list_indicators(metadata_path)}
            if all_meta:
                zf.writestr("indicator_metadata.json", json.dumps(all_meta, indent=2, default=str))
            if indicators_dir.exists():
                for csv_path in sorted(indicators_dir.glob("*.csv")):
                    zf.write(csv_path, arcname=f"indicators/{csv_path.name}")
            for s in sorted(config.session_store.list_all(), key=lambda s: s.session_id):
                if s.context.get("indicator_id"):
                    msgs = clean_messages(s.messages)
                    if msgs:
                        zf.writestr(f"chats/{s.context['indicator_id']}.json", json.dumps(msgs, indent=2))
        buf.seek(0)
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        return StreamingResponse(
            buf, media_type="application/zip",
            headers={"Content-Disposition": f'attachment; filename="backup_{timestamp}.zip"'},
        )

    @router.delete("/indicators/{indicator_id}")
    async def delete_indicator_endpoint(indicator_id: str, country: str = Query(...)):
        meta = get_indicator(metadata_path, indicator_id)
        csv_files = list(indicators_dir.glob(f"{country}__{indicator_id}__*.csv"))
        if not meta and not csv_files:
            raise HTTPException(404, "Indicator not found")
        remaining = [f for f in (meta.csv_files or []) if not f.startswith(f"{country}__")] if meta else []
        if remaining:
            if ob_config.deregister_indicator:
                try:
                    ob_config.deregister_indicator(indicator_id, False, country=country)
                except Exception:
                    logger.warning("Failed to deregister %s for %s", indicator_id, country, exc_info=True)
            remove_country_from_indicator(metadata_path, indicator_id, country, indicators_dir)
        else:
            if ob_config.deregister_indicator:
                try:
                    ob_config.deregister_indicator(indicator_id, True, country=country)
                except Exception:
                    logger.warning("Failed to deregister %s for %s", indicator_id, country, exc_info=True)
            if meta:
                delete_indicator(metadata_path, indicator_id, indicators_dir)
            for f in csv_files:
                if f.exists():
                    f.unlink()
            ob_session = find_onboarding_session(config.session_store, indicator_id)
            if ob_session:
                config.session_store.delete(ob_session.session_id)
        return {"ok": True}

    return router
