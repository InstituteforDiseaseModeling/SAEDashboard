from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

_logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from mind_core.onboarding.metadata_store import IndicatorMetadata


def _default_color_scales() -> set[str]:
    return {
        "BuGn", "BuPu", "GnBu", "OrRd", "PuBu", "PuBuGn", "PuRd", "RdPu", "YlGn",
        "YlGnBu", "YlOrBr", "YlOrRd", "Blues", "Greens", "Greys", "Oranges", "Purples", "Reds",
        "BrBG", "PiYG", "PRGn", "PuOr", "RdBu", "RdGy", "RdYlBu", "RdYlGn", "Spectral",
        "Viridis", "Inferno", "Magma", "Plasma",
        "BuRd", "GnRd", "GnYlRd",
    }


def _default_color_aliases() -> dict[str, str]:
    return {
        "red": "Reds", "blue": "Blues", "green": "Greens", "orange": "Oranges",
        "purple": "Purples", "grey": "Greys", "gray": "Greys",
    }


@dataclass
class OutputColumns:
    """Explicit role-based column specification for indicator CSVs."""
    state: str = "state"
    year: str = "year"
    value: str = "pred"
    value_upper: str = "pred_upper"
    value_lower: str = "pred_lower"

    def as_list(self) -> list[str]:
        return [self.state, self.year, self.value, self.value_upper, self.value_lower]

    def value_columns(self) -> list[str]:
        return [self.value, self.value_upper, self.value_lower]


@dataclass
class OnboardingConfig:
    """Settings for the onboarding subsystem. Dashboard-specific callbacks and content go here."""
    data_dir: str = "/data"
    indicators_subdir: str = "indicators"
    uploads_subdir: str = "uploads"
    metadata_subdir: str = "metadata"

    output_columns: OutputColumns = field(default_factory=OutputColumns)

    register_indicator: Callable[[Path, "IndicatorMetadata"], str | None] | None = None
    deregister_indicator: Callable[[str, bool, str], None] | None = None
    fetch_shape_info: Callable[[], list[dict]] | None = None

    color_scales: set[str] = field(default_factory=_default_color_scales)
    color_aliases: dict[str, str] = field(default_factory=_default_color_aliases)

    geo_columns: list[str] = field(  # [MIND-CORE-IMPROVEMENT]
        default_factory=lambda: ["state", "dot_name", "region", "district", "location", "area", "admin", "name"])
    dot_name_pattern: "re.Pattern | None" = None  # [MIND-CORE-IMPROVEMENT] custom regex for dot_name validation; None = use default

    # this field should describe 'dashboard display fields' in text format (not json)
    display_config_spec: str = ""  # this text is then injected into the system prompt; not parsed by code
    extra_workflow_instructions: str = ""

    @property
    def indicators_dir(self) -> Path:
        d = Path(self.data_dir) / self.indicators_subdir
        d.mkdir(parents=True, exist_ok=True)
        return d

    @property
    def uploads_dir(self) -> Path:
        d = Path(self.data_dir) / self.uploads_subdir
        d.mkdir(parents=True, exist_ok=True)
        return d

    @property
    def metadata_path(self) -> Path:
        d = Path(self.data_dir) / self.metadata_subdir
        old_file = Path(self.data_dir) / "indicator_metadata.json"
        if old_file.exists() and not d.exists():
            _logger.info("Migrating indicator_metadata.json to per-indicator files in %s", d)
            d.mkdir(parents=True, exist_ok=True)
            data = json.loads(old_file.read_text())
            for indicator_id, entry in data.items():
                (d / f"{indicator_id}.json").write_text(json.dumps(entry, indent=2, default=str))
            old_file.unlink()
        else:
            d.mkdir(parents=True, exist_ok=True)
        return d

    @property
    def tmp_dir(self) -> Path:
        d = Path(self.data_dir) / "tmp"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def normalize_color_theme(self, theme: str) -> str:
        if theme in self.color_scales:
            return theme
        return self.color_aliases.get(theme.lower(), "RdBu")
