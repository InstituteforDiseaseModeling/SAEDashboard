import json
from datetime import datetime, timezone
from pathlib import Path

from pydantic import BaseModel, model_validator

from mind_core.storage.atomic import atomic_write_json


class IndicatorMetadata(BaseModel):
    id: str
    display_name: str
    description: str
    country: str
    subgroups: list[str]
    color_theme: str = "RdBu"
    group: str = ""
    shape_version: str = "1"
    hidden_countries: list[str] = []
    is_user_created: bool = True
    created_at: str = ""
    csv_files: list[str] = []
    onboarding_notes: str = ""
    owner_id: str = "local"
    workspace_ids: list[str] = ["default"]
    source_upload_id: str | None = None
    # Display settings set during onboarding (e.g. unit, chart_type).
    # These are NOT updated by the Settings dialog — user edits are
    # stored separately in settings/{id}.json and pushed to the service
    # at startup, overriding these values.
    display_config: dict = {}

    @model_validator(mode="before")
    @classmethod
    def _migrate_hidden(cls, data):
        if isinstance(data, dict) and data.pop("hidden", False) and not data.get("hidden_countries"):
            countries = {f.split("__")[0] for f in data.get("csv_files", []) if "__" in f}
            data["hidden_countries"] = sorted(countries)
        return data

    # TODO: Update other dashboards to use this method
    def to_register_data(self) -> dict[str, str]:
        """Build the form payload for POST /indicators/register."""
        data = {
            "display_name": self.display_name,
            "color_theme": self.color_theme,
            "shape_version": self.shape_version,
            "description": self.description,
            "group": self.group or "user_created",
        }
        if self.display_config:
            data["display_config"] = json.dumps(self.display_config)
        return data


def list_indicators(metadata_dir: Path) -> list[IndicatorMetadata]:
    if not metadata_dir.exists() or not metadata_dir.is_dir():
        return []
    result = []
    for f in sorted(metadata_dir.glob("*.json")):
        try:
            result.append(IndicatorMetadata(**json.loads(f.read_text())))
        except Exception:
            continue
    return result


def get_indicator(metadata_dir: Path, indicator_id: str) -> IndicatorMetadata | None:
    p = metadata_dir / f"{indicator_id}.json"
    if not p.exists():
        return None
    try:
        return IndicatorMetadata(**json.loads(p.read_text()))
    except Exception:
        return None


def save_indicator(metadata_dir: Path, meta: IndicatorMetadata):
    metadata_dir.mkdir(parents=True, exist_ok=True)
    if not meta.created_at:
        meta.created_at = datetime.now(timezone.utc).isoformat()
    atomic_write_json(metadata_dir / f"{meta.id}.json", meta.model_dump())


def next_available_id(metadata_dir: Path, base_id: str) -> str:
    if not (metadata_dir / f"{base_id}.json").exists():
        return base_id
    n = 2
    while (metadata_dir / f"{base_id}_{n}.json").exists():
        n += 1
    return f"{base_id}_{n}"


def update_indicator(metadata_dir: Path, indicator_id: str, **kwargs) -> IndicatorMetadata | None:
    p = metadata_dir / f"{indicator_id}.json"
    if not p.exists():
        return None
    data = json.loads(p.read_text())
    data.update(kwargs)
    atomic_write_json(p, data)
    return IndicatorMetadata(**data)


def toggle_country_hidden(metadata_dir: Path, indicator_id: str, country: str, hide: bool) -> IndicatorMetadata | None:
    p = metadata_dir / f"{indicator_id}.json"
    if not p.exists():
        return None
    data = json.loads(p.read_text())
    meta = IndicatorMetadata(**data)
    countries = set(meta.hidden_countries)
    if hide:
        countries.add(country)
    else:
        countries.discard(country)
    meta.hidden_countries = sorted(countries)
    atomic_write_json(p, meta.model_dump())
    return meta


def delete_indicator(metadata_dir: Path, indicator_id: str, indicators_dir: Path) -> bool:
    p = metadata_dir / f"{indicator_id}.json"
    if not p.exists():
        return False
    try:
        meta = IndicatorMetadata(**json.loads(p.read_text()))
    except Exception:
        p.unlink()
        return True
    p.unlink()
    for csv_file in meta.csv_files:
        csv_path = indicators_dir / csv_file
        if csv_path.exists():
            csv_path.unlink()
    return True


def remove_country_from_indicator(metadata_dir: Path, indicator_id: str, country: str, indicators_dir: Path) -> bool:
    p = metadata_dir / f"{indicator_id}.json"
    if not p.exists():
        return False
    try:
        meta = IndicatorMetadata(**json.loads(p.read_text()))
    except Exception:
        return False
    country_prefix = f"{country}__"
    country_files = [f for f in meta.csv_files if f.startswith(country_prefix)]
    if not country_files:
        return False
    for csv_file in country_files:
        csv_path = indicators_dir / csv_file
        if csv_path.exists():
            csv_path.unlink()
    remaining = [f for f in meta.csv_files if not f.startswith(country_prefix)]
    if remaining:
        meta.csv_files = remaining
        atomic_write_json(p, meta.model_dump())
    else:
        p.unlink()
    return True
