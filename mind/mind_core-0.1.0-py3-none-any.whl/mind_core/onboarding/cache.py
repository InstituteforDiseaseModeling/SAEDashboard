import pandas as pd

# Two caches per session: 'uploads_cache' holds the working copy (transforms
# modify it), 'uploads_cache_original' keeps the untouched original so we
# can reload if a transform goes wrong.
uploads_cache: dict[str, pd.DataFrame] = {}
uploads_cache_original: dict[str, pd.DataFrame] = {}


def get_cached(session_id: str) -> pd.DataFrame | None:
    return uploads_cache.get(session_id)


def get_original(session_id: str) -> pd.DataFrame | None:
    return uploads_cache_original.get(session_id)


def set_cached(session_id: str, df: pd.DataFrame):
    """Store a fresh upload. Saves both working copy and original."""
    uploads_cache[session_id] = df
    uploads_cache_original[session_id] = df.copy()


def update_cached(session_id: str, df: pd.DataFrame):
    """Replace working copy after a transform. Original stays unchanged."""
    uploads_cache[session_id] = df


def clear_cached(session_id: str):
    uploads_cache.pop(session_id, None)
    uploads_cache_original.pop(session_id, None)
