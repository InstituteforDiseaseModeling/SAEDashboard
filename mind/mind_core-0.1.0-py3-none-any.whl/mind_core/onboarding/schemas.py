from mind_core.constants import FILE_SAVED_PREFIX

_ONBOARDING_TOOLS_RAW = [
    {
        "name": "validate_upload",
        "description": "Validate uploaded CSV/Excel file. Returns columns, row count, types, sample rows.",
        "input_schema": {
            "type": "object",
            "properties": {
                "sheet_name": {"type": "string", "description": "Sheet name for multi-sheet Excel files"},
                "upload_id": {"type": "string", "description": "Upload ID (from session context)"},
                "header_row": {"type": "integer", "description": "0-based row index to use as column headers. Omit to auto-detect."},
            },
            "required": [],
            "additionalProperties": False,
        },
    },
    {
        "name": "preview_data",
        "description": "Show summary statistics and sample rows of the currently loaded data.",
        "input_schema": {"type": "object", "properties": {}, "required": [], "additionalProperties": False},
    },
    {
        "name": "transform_csv",
        "description": (
            "Transform loaded data. Keys: rename_columns (dict), drop_columns (list), "
            "add_state_column (lambda string for dot_name), filter_expr (pandas query), "
            "value_transforms (dict of column: lambda string)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "transformations": {
                    "type": "object",
                    "description": "Dict with keys: rename_columns, drop_columns, add_state_column, filter_expr, value_transforms",
                },
            },
            "required": ["transformations"],
            "additionalProperties": False,
        },
    },
    {
        "name": "list_existing_indicators",
        "description": "List all currently registered indicators.",
        "input_schema": {"type": "object", "properties": {}, "required": [], "additionalProperties": False},
    },
    {
        "name": "detect_shape_version",
        "description": "Auto-detect which map boundary version best matches the geographic names in the data.",
        "input_schema": {"type": "object", "properties": {}, "required": [], "additionalProperties": False},
    },
    {
        "name": "resolve_admin_names",
        "description": "Match data geographic names to canonical shape boundary names. Returns rename mapping.",
        "input_schema": {
            "type": "object",
            "properties": {
                "country": {"type": "string", "description": "Country name"},
                "admin_level": {"type": "string", "description": "Admin level"},
                "shape_version": {"type": "string", "description": "Shape version"},
            },
            "required": ["country", "admin_level", "shape_version"],
            "additionalProperties": False,
        },
    },
    {
        "name": "finalize_indicator",
        "description": "Write transformed data as finalized CSV and register metadata. Use for single-subgroup indicators.",
        "input_schema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Indicator ID (snake_case)"},
                "display_name": {"type": "string", "description": "Human-readable name"},
                "description": {"type": "string", "description": "What this indicator measures"},
                "country": {"type": "string", "description": "Country name"},
                "subgroup": {"type": "string", "description": "Subgroup name (e.g. 'all')"},
                "color_theme": {"type": "string", "description": "Color palette for map"},
                "shape_version": {"type": "string", "description": "Map boundary version (from detect_shape_version)"},
                "group": {"type": "string", "description": "Dashboard category/group for this indicator (e.g. 'malaria_epidemiology')"},
                "display_config": {"type": "object", "description": "Dashboard-specific display settings (e.g. unit, chart_type, multiplier)"},
            },
            "required": ["name", "display_name", "description", "country", "subgroup", "shape_version"],
            "additionalProperties": False,
        },
    },
    {
        "name": "batch_finalize_indicator",
        "description": "Finalize indicator with MULTIPLE subgroups. Splits by subgroup column into per-subgroup CSVs.",
        "input_schema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "display_name": {"type": "string"},
                "description": {"type": "string"},
                "country": {"type": "string"},
                "color_theme": {"type": "string"},
                "shape_version": {"type": "string", "description": "Map boundary version (from detect_shape_version)"},
                "group": {"type": "string", "description": "Dashboard category/group for this indicator"},
                "display_config": {"type": "object", "description": "Dashboard-specific display settings (e.g. unit, chart_type, multiplier)"},
                "subgroup_column": {"type": "string"},
                "subgroup_mapping": {"type": "object"},
                "include_all": {"type": "boolean"},
                "all_aggregation": {"type": "string", "enum": ["mean", "median", "sum"]},
                "all_group_columns": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["name", "display_name", "description", "country", "shape_version", "subgroup_column"],
            "additionalProperties": False,
        },
    },
    {
        "name": "execute_python",
        "description": (
            f"Execute Python code for analysis/visualization. Print {FILE_SAVED_PREFIX}/path for outputs."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "Python code to execute"},
                "description": {"type": "string", "description": "Brief description of what this code does"},
            },
            "required": ["code", "description"],
            "additionalProperties": False,
        },
    },
]


def _to_openai_tool(tool: dict) -> dict:
    return {
        "type": "function",
        "function": {
            "name": tool["name"],
            "description": tool["description"],
            "parameters": tool["input_schema"],
        },
    }


ONBOARDING_TOOL_SCHEMAS = [_to_openai_tool(t) for t in _ONBOARDING_TOOLS_RAW]


def get_onboarding_schemas(include_python: bool = True) -> list[dict]:
    """Return tool schemas for onboarding mode. Optionally exclude execute_python."""
    if include_python:
        return list(ONBOARDING_TOOL_SCHEMAS)
    return [s for s in ONBOARDING_TOOL_SCHEMAS if s["function"]["name"] != "execute_python"]
