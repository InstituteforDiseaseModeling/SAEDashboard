from mind_core.onboarding.config import OnboardingConfig, OutputColumns
from mind_core.onboarding.metadata_store import IndicatorMetadata, list_indicators, get_indicator, save_indicator, delete_indicator
from mind_core.onboarding.uploads_store import Upload, save_upload, get_upload
from mind_core.onboarding.indicator_index import build_index, get_cached_index, invalidate_index
from mind_core.onboarding.session_helpers import (
    start_onboarding, end_onboarding, get_onboarding_context,
    get_upload_id, get_indicator_id, find_onboarding_session,
)
from mind_core.onboarding.prompt_template import ONBOARDING_WORKFLOW_INSTRUCTIONS, build_onboarding_prompt
from mind_core.onboarding.schemas import ONBOARDING_TOOL_SCHEMAS, get_onboarding_schemas
from mind_core.onboarding.hooks import make_onboarding_post_tool_hook, make_onboarding_request_hook
from mind_core.onboarding.progress import onboarding_progress_message
from mind_core.onboarding.routes import create_onboarding_upload_router, create_indicators_router
from mind_core.onboarding.tools import validate_upload, preview_data, transform_csv, list_existing_indicators, rank_shape_matches, build_name_mapping
from mind_core.onboarding.finalize import finalize_indicator, batch_finalize_indicator

from mind_core.session import Session
from mind_core.types import ToolResult


def make_onboarding_dispatch(ob_config: OnboardingConfig) -> dict:
    """Build the tool dispatch dict for onboarding mode.

    Returns {tool_name: handler_fn} where each handler takes (input_dict, session).
    The dispatch connects LLM tool calls to the actual Python functions.
    """
    # [MIND-CORE-IMPROVEMENT] apply configurable geo_columns and dot_name_pattern
    from mind_core.onboarding.tools import set_geo_columns
    from mind_core.onboarding.csv_validator import set_dot_name_pattern
    set_geo_columns(ob_config.geo_columns)
    if ob_config.dot_name_pattern is not None:
        set_dot_name_pattern(ob_config.dot_name_pattern)

    def _validate_upload(inp: dict, session: Session) -> ToolResult:
        upload_id = inp.get("upload_id") or get_upload_id(session)
        result = validate_upload(ob_config, session.session_id, inp.get("sheet_name"), upload_id,
                                 header_row=inp.get("header_row"))
        return ToolResult(output=result)

    def _preview_data(inp: dict, session: Session) -> ToolResult:
        return ToolResult(output=preview_data(session.session_id))

    def _transform_csv(inp: dict, session: Session) -> ToolResult:
        return ToolResult(output=transform_csv(session.session_id, inp.get("transformations", {})))

    def _list_existing(inp: dict, session: Session) -> ToolResult:
        return ToolResult(output=list_existing_indicators(ob_config))

    def _fetch_shapes() -> list[dict]:
        """Get all available shapes from the dashboard's service layer."""
        if ob_config.fetch_shape_info is None:
            return []
        return ob_config.fetch_shape_info()

    def _detect_shape(inp: dict, session: Session) -> ToolResult:
        """Score data against all shape sets, return ranked results."""
        from mind_core.onboarding.cache import get_cached
        df = get_cached(session.session_id)
        if df is None:
            return ToolResult(output="ERROR: No data loaded. Call validate_upload first.")
        shapes_info = _fetch_shapes()
        if not shapes_info:
            return ToolResult(output="ERROR: No shape data available. fetch_shape_info not configured.")
        return ToolResult(output=rank_shape_matches(df, shapes_info))

    def _resolve_names(inp: dict, session: Session) -> ToolResult:
        """Match data geo names to canonical shape names for the chosen version."""
        from mind_core.onboarding.cache import get_cached
        from mind_core.onboarding.tools import _find_geo_column, _active_geo_columns  # [MIND-CORE-IMPROVEMENT]
        df = get_cached(session.session_id)
        if df is None:
            return ToolResult(output="ERROR: No data loaded. Call validate_upload first.")
        geo_col = _find_geo_column(df)
        if geo_col is None:
            return ToolResult(output="No geographic column found. Expected one of: " + ", ".join(_active_geo_columns))  # [MIND-CORE-IMPROVEMENT]
        data_names = list(df[geo_col].dropna().unique())
        country = inp["country"]
        admin_level = inp["admin_level"]
        shape_version = inp["shape_version"]
        shapes_info = _fetch_shapes()
        canonical_names = []
        for s in shapes_info:
            if (str(s["country"]) == country
                    and str(s["admin_level"]) == str(admin_level)
                    and str(s["version"]) == str(shape_version)):
                canonical_names = s.get("admin_names", [])
                break
        if not canonical_names:
            return ToolResult(output=f"ERROR: No shape found for {country} admin_level={admin_level} version={shape_version}")
        return ToolResult(output=build_name_mapping(data_names, canonical_names))

    def _finalize(inp: dict, session: Session) -> ToolResult:
        result = finalize_indicator(
            ob_config, session.session_id,
            inp["name"], inp["display_name"], inp["description"],
            inp["country"], inp["subgroup"],
            inp.get("color_theme", "RdBu"), inp["shape_version"],
            group=inp.get("group", ""),
            display_config=inp.get("display_config"),
        )
        return ToolResult(output=result)

    def _batch_finalize(inp: dict, session: Session) -> ToolResult:
        result = batch_finalize_indicator(
            ob_config, session.session_id,
            inp["name"], inp["display_name"], inp["description"],
            inp["country"],
            inp.get("color_theme", "RdBu"), inp["shape_version"],
            inp["subgroup_column"], inp.get("subgroup_mapping"),
            inp.get("include_all", True), inp.get("all_aggregation", "mean"),
            inp.get("all_group_columns"),
            group=inp.get("group", ""),
            display_config=inp.get("display_config"),
        )
        return ToolResult(output=result)

    return {
        "validate_upload": _validate_upload,
        "preview_data": _preview_data,
        "transform_csv": _transform_csv,
        "list_existing_indicators": _list_existing,
        "detect_shape_version": _detect_shape,
        "resolve_admin_names": _resolve_names,
        "finalize_indicator": _finalize,
        "batch_finalize_indicator": _batch_finalize,
    }
