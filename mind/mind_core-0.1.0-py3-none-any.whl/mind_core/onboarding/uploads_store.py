import json
from datetime import datetime, timezone
from pathlib import Path

from pydantic import BaseModel

from mind_core.storage.atomic import atomic_write_json


class Upload(BaseModel):
    upload_id: str
    filename: str
    stored_path: str
    uploaded_at: str = ""
    size: int = 0
    preserve: bool = True


def _sidecar_path(uploads_dir: Path, upload_id: str) -> Path:
    return uploads_dir / upload_id / "upload.json"


def save_upload(uploads_dir: Path, upload: Upload):
    if not upload.uploaded_at:
        upload.uploaded_at = datetime.now(timezone.utc).isoformat()
    atomic_write_json(_sidecar_path(uploads_dir, upload.upload_id), upload.model_dump())


def get_upload(uploads_dir: Path, upload_id: str) -> Upload | None:
    p = _sidecar_path(uploads_dir, upload_id)
    if not p.exists():
        return None
    return Upload(**json.loads(p.read_text()))


def mark_upload_transient(uploads_dir: Path, upload_id: str) -> bool:
    upload = get_upload(uploads_dir, upload_id)
    if upload is None:
        return False
    upload.preserve = False
    save_upload(uploads_dir, upload)
    return True
