import json
import re
import unicodedata
from pathlib import Path

import pandas as pd

from mind_core.constants import MULTI_SHEET_SENTINEL
from mind_core.onboarding.cache import get_cached, get_original, set_cached, update_cached
from mind_core.onboarding.config import OnboardingConfig
from mind_core.onboarding.csv_validator import load_upload, get_upload_summary, detect_mixed_admin_levels
from mind_core.onboarding.metadata_store import list_indicators


def _resolve_upload_path(ob_config: OnboardingConfig, session_id: str, upload_id: str | None = None) -> Path | None:
    """Find the uploaded file on disk. Returns None if missing."""
    d = ob_config.uploads_dir / (upload_id or session_id)
    if not d.exists():
        return None
    files = [f for f in d.iterdir() if f.is_file() and f.name != "upload.json"]
    return files[0] if files else None


def validate_upload(ob_config: OnboardingConfig, session_id: str, sheet_name: str | None = None,
                    upload_id: str | None = None, header_row: int | None = None) -> str:
    """Read uploaded file into cache and return a text summary for the LLM."""
    path = _resolve_upload_path(ob_config, session_id, upload_id)
    if path is None:
        return "ERROR: No uploaded file found."
    try:
        df, info = load_upload(path, sheet_name, header_row=header_row)
        set_cached(session_id, df)
    except Exception as e:
        return f"ERROR: Failed to read file: {e}"
    summary = get_upload_summary(df)
    sheets_note = ""
    if info.get("sheets") and len(info["sheets"]) > 1:
        sheets_note = f"\n{MULTI_SHEET_SENTINEL}: {info['sheets']}. Currently reading: {sheet_name or info['sheets'][0]}"

    header_note = ""
    detected = info.get("detected_header_row", 0)
    confidence = info.get("header_confidence", 1.0)
    if detected != 0:
        header_note = f"\nNote: Header row detected at row {detected + 1} (0-indexed: {detected}), skipping {detected} preamble row(s)."
    if confidence is not None and confidence < 0.7:
        header_note += (
            f"\n⚠ Header detection is uncertain (confidence: {confidence:.0%}). "
            f"Detected row {detected + 1} as header. Please confirm with the user before "
            "proceeding, or call validate_upload with an explicit header_row."
        )

    admin_note = ""
    mixed = detect_mixed_admin_levels(df)
    if mixed:
        lvl_desc = ", ".join(f"level {k}: {v} rows" for k, v in mixed["levels"].items())
        admin_note = (
            f"\n⚠ Mixed admin levels detected (column: '{mixed['level_col']}'): {lvl_desc}."
        )
        if mixed["aggregation_confirmed"]:
            admin_note += " Parent rows appear to be aggregations of their children (sum cross-check passed)."
        if mixed["confidence"] < 0.7:
            admin_note += (
                f" Detection confidence: {mixed['confidence']:.0%} — ask the user to confirm"
                " which admin level to use before proceeding."
            )
        else:
            admin_note += (
                " You MUST filter to a single admin level before finalizing."
                " Add an `admin_level` field to Form 1 so the user can choose which level to keep."
                f" Use transform_csv with filter_expr=\"{mixed['level_col']} == <chosen_level>\" to filter."
            )

    return f"File: {path.name} ({info['file_type']}){sheets_note}{header_note}{admin_note}\n\n{summary}"


def preview_data(session_id: str) -> str:
    """Return summary stats and sample rows from the cached DataFrame."""
    df = get_cached(session_id)
    if df is None:
        return "ERROR: No data loaded. Call validate_upload first."
    return get_upload_summary(df)


def transform_csv(session_id: str, transformations: dict) -> str:
    """Apply renames, drops, filters, and computed columns to cached data."""
    if isinstance(transformations, str):
        try:
            transformations = json.loads(transformations)
        except json.JSONDecodeError:
            return f"ERROR: transformations must be a JSON object, got string: {transformations[:200]}"
    df = get_cached(session_id)
    if df is None:
        return "ERROR: No data loaded. Call validate_upload first."
    df = df.copy()

    if "rename_columns" in transformations:
        df = df.rename(columns=transformations["rename_columns"])
    if "drop_columns" in transformations:
        df = df.drop(columns=[c for c in transformations["drop_columns"] if c in df.columns])
    if "add_state_column" in transformations:
        expr = transformations["add_state_column"]
        try:
            df["state"] = df.eval(expr) if isinstance(expr, str) and not expr.startswith("lambda") else df.apply(eval(expr), axis=1)
        except Exception as e:
            return f"ERROR: Failed to create state column: {e}"
    if "filter_expr" in transformations:
        try:
            df = df.query(transformations["filter_expr"])
        except Exception as e:
            return f"ERROR: Filter failed: {e}"
    if "value_transforms" in transformations:
        for col, expr in transformations["value_transforms"].items():
            if col in df.columns:
                try:
                    df[col] = df[col].apply(eval(expr))
                except Exception as e:
                    return f"ERROR: Transform on {col} failed: {e}"

    update_cached(session_id, df)
    return f"Transformed. New shape: {df.shape}\nColumns: {list(df.columns)}\n\nFirst 3 rows:\n{df.head(3).to_string()}"


def list_existing_indicators(ob_config: OnboardingConfig) -> str:
    """List all registered indicators as text for the LLM."""
    indicators = list_indicators(ob_config.metadata_path)
    if not indicators:
        return "No user-created indicators found."
    lines = []
    for ind in indicators:
        status = f"HIDDEN({','.join(ind.hidden_countries)})" if ind.hidden_countries else "visible"
        lines.append(f"- {ind.id} ({ind.display_name}) [{status}] — {ind.description[:80]}")
    return "\n".join(lines)


def _normalize(s: str) -> str:
    """Strip accents and lowercase. 'Kédougou' becomes 'kedougou'."""
    return unicodedata.normalize("NFD", s).encode("ascii", "ignore").decode().lower()


GEO_COLUMNS = ["state", "dot_name", "region", "district", "location", "area", "admin", "name"]

_active_geo_columns: list[str] = GEO_COLUMNS  # [MIND-CORE-IMPROVEMENT] overridden by set_geo_columns()


def set_geo_columns(columns: list[str]) -> None:  # [MIND-CORE-IMPROVEMENT]
    """Override which column names count as geographic."""
    global _active_geo_columns
    _active_geo_columns = columns


def _find_geo_column(df: pd.DataFrame) -> str | None:
    """Find the first column whose name matches a known geographic column name."""
    return next((c for c in df.columns if c.lower() in _active_geo_columns), None)  # [MIND-CORE-IMPROVEMENT]


def _match_against_shape(geo_norm: dict[str, str], admin_names: list[str]) -> tuple[int, int]:
    """Count how many data names match one shape set. Returns (matched, total_shapes).

    Two match strategies per name:
    1. Exact normalized match — both sides stripped/lowered, compared directly.
    2. Suffix fallback — compare only the last segment after ':'.
    """
    shape_norm = {_normalize(dn): dn for dn in admin_names}
    # Build suffix index: last segment -> list of shape names with that suffix
    shape_suffixes: dict[str, list[str]] = {}
    for norm_dn, orig_dn in shape_norm.items():
        last = norm_dn.rsplit(":", 1)[-1]
        shape_suffixes.setdefault(last, []).append(orig_dn)
    matched = sum(1 for gn in geo_norm if gn in shape_norm or gn.rsplit(":", 1)[-1] in shape_suffixes)
    return matched, len(admin_names)


def rank_shape_matches(df: pd.DataFrame, shapes_info: list[dict]) -> str:
    """Pick the best map boundary version for the uploaded data.

    Scores each shape set by how many data region names it can match,
    then returns a ranked text report the LLM reads to choose shape_version.
    See docs/design.md 'Shape Detection' for the full algorithm.
    """
    geo_col = _find_geo_column(df)
    if geo_col is None:
        return "No geographic column found. Expected one of: " + ", ".join(_active_geo_columns)  # [MIND-CORE-IMPROVEMENT]

    geo_values = set(df[geo_col].dropna().unique())
    if not geo_values:
        return "Geographic column is empty."
    geo_norm = {_normalize(str(v)): v for v in geo_values}

    if not shapes_info:
        return "No shape data available."

    # Score every shape set against the data names
    results = []
    for shape in shapes_info:
        admin_names = shape.get("admin_names", [])
        matched, shape_count = _match_against_shape(geo_norm, admin_names)
        rate = matched / len(geo_values) if geo_values else 0
        results.append({
            "country": shape["country"],
            "admin_level": str(shape["admin_level"]),
            "shape_version": str(shape["version"]),
            "shape_regions": shape_count,
            "data_regions": len(geo_values),
            "matched": matched,
            "match_rate": rate,
        })

    # Best = highest percentage of data names matched, tiebreak by count
    results.sort(key=lambda r: (-r["match_rate"], -r["matched"]))
    best = results[0]
    lines = [f"Shape version detection (column: '{geo_col}', {len(geo_values)} unique values):\n"]
    for r in results:
        marker = "  ** BEST MATCH" if r is best else ""
        lines.append(
            f"  {r['country']} admin_level={r['admin_level']} shape_version={r['shape_version']}: "
            f"{r['matched']}/{r['data_regions']} matched ({r['match_rate']:.0%}), "
            f"{r['shape_regions']} shapes{marker}"
        )
    lines.append(f"\nRecommended: shape_version={best['shape_version']}, admin_level={best['admin_level']}")
    if best["match_rate"] < 0.5:
        lines.append("WARNING: Low match rate.")
    return "\n".join(lines)


def build_name_mapping(data_names: list[str], canonical_names: list[str]) -> str:
    """Match data region names to canonical shape names. Returns a text report.

    Two-level matching per name:
    1. Exact normalized — strip accents + lowercase both sides, compare.
    2. Suffix fallback — match only the last segment after ':',
       but only if there's exactly one canonical candidate for that suffix.

    Output tells the LLM which names to rename and which are unresolved.
    See docs/design.md 'Name Resolution' for the full algorithm.
    """
    # Normalized index: normalized_canonical -> original_canonical
    canon_norm = {_normalize(cn): cn for cn in canonical_names}
    # Suffix index: last_segment -> [canonical names sharing that suffix]
    canon_suffixes: dict[str, list[str]] = {}
    for norm_cn, orig_cn in canon_norm.items():
        last = norm_cn.rsplit(":", 1)[-1]
        canon_suffixes.setdefault(last, []).append(orig_cn)

    mapping: dict[str, str] = {}
    unmatched: list[str] = []
    for dn in data_names:
        norm = _normalize(dn)
        # Level 1: exact normalized match
        if norm in canon_norm:
            canonical = canon_norm[norm]
            if canonical != dn:
                mapping[dn] = canonical
        else:
            # Level 2: suffix-only match (must be unambiguous)
            suffix = norm.rsplit(":", 1)[-1]
            candidates = canon_suffixes.get(suffix)
            if candidates and len(candidates) == 1:
                mapping[dn] = candidates[0]
            else:
                unmatched.append(dn)

    lines = [f"Name resolution: {len(data_names)} data names, {len(canonical_names)} canonical names"]
    matched_count = len(data_names) - len(unmatched)
    lines.append(f"Matched: {matched_count}/{len(data_names)} ({matched_count/len(data_names):.0%})" if data_names else "No data names.")

    if mapping:
        lines.append("\nRename mapping (data_name -> canonical_name):")
        for src, dst in sorted(mapping.items()):
            lines.append(f"  {src} -> {dst}")

    if unmatched:
        lines.append(f"\nUnmatched ({len(unmatched)}):")
        for u in sorted(unmatched):
            lines.append(f"  {u}")

    return "\n".join(lines)
