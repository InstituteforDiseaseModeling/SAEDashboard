import json
import re

import pandas as pd

from mind_core.constants import FINALIZE_SUCCESS_SENTINEL
from mind_core.onboarding.cache import get_cached, get_original
from mind_core.onboarding.config import OnboardingConfig, OutputColumns
from mind_core.onboarding.csv_validator import validate_output_csv
from mind_core.onboarding.metadata_store import (
    IndicatorMetadata,
    list_indicators,
    next_available_id,
    save_indicator,
)

_DEFAULT_OUTPUT_COLUMNS = OutputColumns()


def _align_reference_columns(
    df: pd.DataFrame, indicator_name: str,
    output_columns: OutputColumns | None = None,
) -> pd.DataFrame:
    """Rename leftover numeric columns to match the indicator naming pattern."""
    oc = output_columns or _DEFAULT_OUTPUT_COLUMNS
    preserve = set(oc.as_list()) | {"month"}
    renames = {}
    drops = []
    ref_found = indicator_name in df.columns
    se_found = f"se.{indicator_name}" in df.columns
    for col in df.columns:
        if col in preserve or col == indicator_name or col == f"se.{indicator_name}":
            continue
        if not pd.api.types.is_numeric_dtype(df[col]):
            drops.append(col)
        elif col.startswith("se.") and not se_found:
            renames[col] = f"se.{indicator_name}"
            se_found = True
        elif not ref_found:
            renames[col] = indicator_name
            ref_found = True
        else:
            drops.append(col)
    if drops:
        df = df.drop(columns=drops)
    if renames:
        df = df.rename(columns=renames)
    return df


def _csv_filename(country: str, name: str, subgroup: str, shape_version: str) -> str:
    return f"{country}__{name}__{subgroup}__{shape_version}.csv"


def _merge_into_existing(meta: IndicatorMetadata, existing_meta: IndicatorMetadata) -> None:
    """Fold a new upload into an existing indicator with the same id.

    The same indicator may span several countries / shape versions; each lives
    in its own CSV, so csv_files is the per-file record. country and
    shape_version keep the values from the first onboarding. Countries hidden
    from the dashboard stay hidden."""
    meta.country = existing_meta.country
    meta.shape_version = existing_meta.shape_version
    meta.subgroups = sorted(set(existing_meta.subgroups + meta.subgroups))
    meta.csv_files = sorted(set(existing_meta.csv_files + meta.csv_files))
    meta.created_at = existing_meta.created_at
    meta.hidden_countries = list(existing_meta.hidden_countries)


# Appended to the finalize summary instead of "now available in the dashboard" when the
# data was added to a country that the user hid from the dashboard
_HIDDEN_COUNTRY_NOTE = (
    "{country} is hidden from the dashboard for this indicator, so the new data was saved but "
    "not added to the dashboard. Inform users to use 'Add to Dashboard' in Manage Indicators to show it."
)


def _sanitize_subgroup_name(value: str) -> str:
    s = str(value).strip()
    s = re.sub(r'[\s]+', '-', s)
    s = re.sub(r'[^A-Za-z0-9\-_]', '_', s)
    s = re.sub(r'_+', '_', s).strip('_')
    return s or "unknown"


def finalize_indicator(
    ob_config: OnboardingConfig, session_id: str,
    name: str, display_name: str, description: str,
    country: str, subgroup: str,
    color_theme: str, shape_version: str = "1",
    group: str = "",
    display_config: dict | None = None,
) -> str:
    """Write CSV, validate, save metadata, register with service."""
    color_theme = ob_config.normalize_color_theme(color_theme)
    if get_cached(session_id) is None:
        return "ERROR: No data loaded. Call validate_upload and transform_csv first."

    existing = list_indicators(ob_config.metadata_path)
    existing_meta = next((i for i in existing if i.id == name), None)
    is_merge = False
    rename_note = ""
    if existing_meta:
        # Only rename when the exact file (country + subgroup + shape version) is taken;
        # a different country or shape version extends the existing indicator.
        if _csv_filename(country, name, subgroup, shape_version) in existing_meta.csv_files:
            new_id = next_available_id(ob_config.metadata_path, name)
            rename_note = f" (renamed id '{name}' -> '{new_id}' to avoid overwriting an existing indicator)"
            name = new_id
        else:
            is_merge = True

    df = _align_reference_columns(get_cached(session_id), name, ob_config.output_columns)
    ind_dir = ob_config.indicators_dir
    filename = _csv_filename(country, name, subgroup, shape_version)
    output_path = ind_dir / filename
    df.to_csv(output_path, index=False)

    issues = validate_output_csv(output_path, ob_config.output_columns)
    if issues:
        output_path.unlink()
        return "ERROR: Validation failed:\n" + "\n".join(f"  - {i}" for i in issues)

    meta = IndicatorMetadata(
        id=name, display_name=display_name, description=description,
        country=country, subgroups=[subgroup],
        color_theme=color_theme, group=group, shape_version=shape_version,
        csv_files=[filename], onboarding_notes=f"Onboarded in session {session_id}",
        display_config=display_config or {},
    )
    if is_merge:
        _merge_into_existing(meta, existing_meta)
    save_indicator(ob_config.metadata_path, meta)

    row_count = len(df)
    year_range = f", years {df['year'].min()}-{df['year'].max()}" if "year" in df.columns else ""
    regions = f", {df['state'].nunique()} regions" if "state" in df.columns else ""

    summary = f"Indicator '{display_name}'{rename_note} {FINALIZE_SUCCESS_SENTINEL}.\nFile: {filename} ({row_count} rows{year_range}{regions})\nColor theme: {color_theme}\nMETA:INDICATOR_ID={name}\n"

    if country in meta.hidden_countries:
        summary += _HIDDEN_COUNTRY_NOTE.format(country=country)
    elif ob_config.register_indicator:
        warning = ob_config.register_indicator(output_path, meta)
        if warning:
            summary += warning
        else:
            summary += "The indicator is now available in the dashboard."
    else:
        summary += "The indicator has been saved."

    return summary


def batch_finalize_indicator(
    ob_config: OnboardingConfig, session_id: str,
    name: str, display_name: str, description: str,
    country: str, color_theme: str, shape_version: str,
    subgroup_column: str, subgroup_mapping: dict | None = None,
    include_all: bool = True, all_aggregation: str = "mean",
    all_group_columns: list[str] | None = None,
    group: str = "",
    display_config: dict | None = None,
) -> str:
    """Split data by subgroup column, finalize each as a separate CSV."""
    color_theme = ob_config.normalize_color_theme(color_theme)
    if isinstance(all_group_columns, str):
        all_group_columns = [c.strip() for c in all_group_columns.split(",") if c.strip()]
    if isinstance(subgroup_mapping, str):
        try:
            subgroup_mapping = json.loads(subgroup_mapping)
        except (ValueError, json.JSONDecodeError):
            subgroup_mapping = None

    df = get_cached(session_id)
    if df is None:
        return "ERROR: No data loaded."
    if subgroup_column not in df.columns:
        orig = get_original(session_id)
        if orig is not None and subgroup_column in orig.columns:
            df[subgroup_column] = orig[subgroup_column]
        else:
            return f"ERROR: Column '{subgroup_column}' not found."

    unique_values = df[subgroup_column].dropna().unique().tolist()
    if not unique_values:
        return "ERROR: Subgroup column has no values."

    proposed_subgroups = [
        (subgroup_mapping or {}).get(str(v), _sanitize_subgroup_name(v)) for v in unique_values
    ]
    if include_all:
        proposed_subgroups.append("all")
    existing_for_collision = list_indicators(ob_config.metadata_path)
    existing_for_id = next((i for i in existing_for_collision if i.id == name), None)
    rename_note = ""
    if existing_for_id:
        proposed_files = {_csv_filename(country, name, sg, shape_version) for sg in proposed_subgroups}
        if proposed_files & set(existing_for_id.csv_files):
            new_id = next_available_id(ob_config.metadata_path, name)
            rename_note = f" (renamed id '{name}' -> '{new_id}' to avoid overwriting an existing indicator)"
            name = new_id
    # Data added to a country hidden from the dashboard is saved but not registered
    country_hidden = bool(existing_for_id and not rename_note
                          and country in existing_for_id.hidden_countries)

    ind_dir = ob_config.indicators_dir
    mapping = subgroup_mapping or {}
    created, warnings, all_filenames = [], [], []

    tasks = [(v, mapping.get(str(v), _sanitize_subgroup_name(v))) for v in unique_values]
    if include_all:
        tasks.append((None, "all"))

    force_group = {ob_config.output_columns.state, ob_config.output_columns.year, "month", "dot_name"}
    for raw_value, sg_name in tasks:
        if raw_value is None:
            subset = df.drop(columns=[subgroup_column])
            if all_group_columns:
                group_cols = [c for c in all_group_columns if c in subset.columns]
            else:
                num_cols_set = set(subset.select_dtypes(include="number").columns)
                group_cols = [c for c in subset.columns if c not in num_cols_set or c.lower() in force_group]
            num_cols = [c for c in subset.columns if c not in group_cols and pd.api.types.is_numeric_dtype(subset[c])]
            if not group_cols or not num_cols:
                warnings.append(f"  - all: skipped (cannot determine group/value columns)")
                continue
            agg_func = all_aggregation if all_aggregation in ("mean", "median", "sum") else "mean"
            subset = subset.groupby(group_cols, as_index=False)[num_cols].agg(agg_func)
        else:
            subset = df[df[subgroup_column] == raw_value].drop(columns=[subgroup_column])

        if subset.empty:
            warnings.append(f"  - {sg_name}: skipped (no rows)")
            continue

        subset = _align_reference_columns(subset, name, ob_config.output_columns)
        filename = _csv_filename(country, name, sg_name, shape_version)
        output_path = ind_dir / filename
        subset.to_csv(output_path, index=False)

        issues = validate_output_csv(output_path, ob_config.output_columns)
        if issues:
            output_path.unlink()
            warnings.append(f"  - {sg_name}: validation failed — {'; '.join(issues)}")
            continue

        all_filenames.append(filename)
        created.append(sg_name)

        if ob_config.register_indicator and not country_hidden:
            temp_meta = IndicatorMetadata(
                id=name, display_name=display_name, description=description,
                country=country, subgroups=[sg_name],
                color_theme=color_theme, group=group, shape_version=shape_version,
                csv_files=[filename], display_config=display_config or {},
            )
            warning = ob_config.register_indicator(output_path, temp_meta)
            if warning:
                warnings.append(f"  - {sg_name}: {warning}")

    if not created:
        return "ERROR: No subgroups created.\n" + "\n".join(warnings)

    meta = IndicatorMetadata(
        id=name, display_name=display_name, description=description,
        country=country, subgroups=created,
        color_theme=color_theme, group=group, shape_version=shape_version,
        csv_files=all_filenames, onboarding_notes=f"Batch onboarded in session {session_id}",
        display_config=display_config or {},
    )
    if not rename_note:
        existing_meta = next((i for i in list_indicators(ob_config.metadata_path) if i.id == name), None)
        if existing_meta:
            _merge_into_existing(meta, existing_meta)
    save_indicator(ob_config.metadata_path, meta)

    summary = f"Indicator '{display_name}'{rename_note} {FINALIZE_SUCCESS_SENTINEL}.\nCreated {len(created)} subgroup(s): {', '.join(created)}\nColor theme: {color_theme}\nMETA:INDICATOR_ID={name}\n"
    if warnings:
        summary += "Warnings:\n" + "\n".join(warnings) + "\n"
    if country_hidden:
        summary += _HIDDEN_COUNTRY_NOTE.format(country=country)
    else:
        summary += "The indicator is now available in the dashboard."
    return summary
