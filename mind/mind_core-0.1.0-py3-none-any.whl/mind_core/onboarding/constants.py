import re

# [MIND-CORE-IMPROVEMENT] single source of truth — previously duplicated in csv_validator, routes/indicators, finalize
DATA_FILE_REGEX = re.compile(
    r'^(?P<country>.+)__(?P<channel>.+)__(?P<subgroup>.+)__(?P<version>.+)\.csv$')
