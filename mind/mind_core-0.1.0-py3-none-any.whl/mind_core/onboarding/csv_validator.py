import re
from collections import Counter
from pathlib import Path

import pandas as pd

from mind_core.onboarding.config import OutputColumns
from mind_core.onboarding.constants import DATA_FILE_REGEX as MASTER_DATA_FILE_REGEX  # [MIND-CORE-IMPROVEMENT] deduplicated

# Validates colon-separated names like "Africa:Senegal:Dakar".
# First segment: letters only. Later segments: letters, spaces, hyphens, accented chars.
DOT_NAME_PATTERN = re.compile(r'^[A-Za-z]+(?::[A-Za-z\s\-\u00C0-\u024F]+)+$')

_active_dot_name_pattern: re.Pattern = DOT_NAME_PATTERN  # [MIND-CORE-IMPROVEMENT] overridden by set_dot_name_pattern()


def set_dot_name_pattern(pattern: re.Pattern) -> None:  # [MIND-CORE-IMPROVEMENT]
    global _active_dot_name_pattern
    _active_dot_name_pattern = pattern

_DEFAULT_OUTPUT_COLUMNS = OutputColumns()


MAX_DETECT_ROWS = 20


def _looks_like_header_cell(val) -> bool:
    if val is None or (isinstance(val, float) and pd.isna(val)):
        return False
    s = str(val).strip()
    if not s or len(s) > 60:
        return False
    try:
        float(s.replace(",", ""))
        return False
    except ValueError:
        pass
    return True


def _detect_header_row(raw_df: pd.DataFrame) -> tuple[int, float]:
    """Score first N rows to find the most likely header row.

    raw_df must be read with header=None so all file rows are in .iloc.
    Returns (0-based file row index, confidence 0.0-1.0).
    """
    n_rows = min(MAX_DETECT_ROWS, len(raw_df))
    n_cols = raw_df.shape[1]
    if n_cols == 0 or n_rows == 0:
        return 0, 1.0

    scores = []
    for i in range(n_rows):
        row_vals = list(raw_df.iloc[i])
        header_cells = sum(1 for v in row_vals if _looks_like_header_cell(v))
        scores.append(header_cells / n_cols)

    best_idx = max(range(len(scores)), key=lambda i: scores[i])
    best_score = scores[best_idx]
    second_best = max(s for i, s in enumerate(scores) if i != best_idx) if len(scores) > 1 else 0.0
    gap = best_score - second_best
    confidence = min(1.0, gap * 2 + (0.5 if best_score > 0.6 else 0.0))
    return best_idx, round(confidence, 2)


def load_upload(path: Path, sheet_name: str | None = None,
                header_row: int | None = None) -> tuple[pd.DataFrame, dict]:
    """Read CSV or Excel file into a DataFrame. Returns (df, info_dict)."""
    info = {"file_type": path.suffix.lower(), "sheets": None,
            "detected_header_row": None, "header_confidence": None}
    is_excel = path.suffix.lower() in ('.xlsx', '.xls')

    if header_row is not None:
        if is_excel:
            xls = pd.ExcelFile(path)
            info["sheets"] = xls.sheet_names
            target = sheet_name or xls.sheet_names[0]
            df = pd.read_excel(xls, sheet_name=target, header=header_row)
        else:
            df = pd.read_csv(path, header=header_row)
        info["detected_header_row"] = header_row
        info["header_confidence"] = 1.0
    else:
        if is_excel:
            xls = pd.ExcelFile(path)
            info["sheets"] = xls.sheet_names
            target = sheet_name or xls.sheet_names[0]
            raw = pd.read_excel(xls, sheet_name=target, header=None)
        else:
            raw = pd.read_csv(path, header=None)

        detected, confidence = _detect_header_row(raw)
        info["detected_header_row"] = detected
        info["header_confidence"] = confidence

        if is_excel:
            df = pd.read_excel(xls, sheet_name=target, header=detected)
        else:
            df = pd.read_csv(path, header=detected)

    info["columns"] = list(df.columns)
    info["row_count"] = len(df)
    info["dtypes"] = {col: str(df[col].dtype) for col in df.columns}
    return df, info


def validate_output_csv(path: Path, output_columns: OutputColumns | None = None) -> list[str]:
    """Check a finalized CSV for required columns, valid formats, and bounds ordering."""
    oc = output_columns or _DEFAULT_OUTPUT_COLUMNS
    issues = []
    try:
        df = pd.read_csv(path)
    except Exception as e:
        return [f"Cannot read CSV: {e}"]

    for col in oc.as_list():
        if col not in df.columns:
            issues.append(f"Missing required column: {col}")

    if oc.state in df.columns:
        bad = [s for s in df[oc.state].dropna().head(20) if not _active_dot_name_pattern.match(str(s))]  # [MIND-CORE-IMPROVEMENT]
        if bad:
            issues.append(f"Invalid dot_name format in '{oc.state}': {bad[:3]}")

    for col in oc.value_columns():
        if col in df.columns and not pd.api.types.is_numeric_dtype(df[col]):
            issues.append(f"Column '{col}' must be numeric")

    mid, lower, upper = oc.value, oc.value_lower, oc.value_upper
    if all(c in df.columns and pd.api.types.is_numeric_dtype(df[c]) for c in [mid, lower, upper]):
        valid = df[[mid, lower, upper]].dropna()
        if len(valid) > 0:
            violations = (valid[lower] > valid[mid]).sum() + (valid[mid] > valid[upper]).sum()
            if violations > 0:
                issues.append(f"{violations} rows where {lower} > {mid} or {mid} > {upper}")

    if not MASTER_DATA_FILE_REGEX.match(path.name):
        issues.append(f"Filename '{path.name}' doesn't match pattern: {{Country}}__{{Indicator}}__{{Subgroup}}__{{Version}}.csv")

    return issues


_ADMIN_LEVEL_RE = re.compile(r'^(adm_?level|admin_?level|level)$', re.IGNORECASE)


def _find_admin_level_col(df: pd.DataFrame) -> str | None:
    return next((c for c in df.columns if _ADMIN_LEVEL_RE.match(str(c).strip())), None)


def _check_aggregation_sums(df: pd.DataFrame, level_col: str,
                            sorted_levels: list) -> tuple[bool, float]:
    """Cross-check whether parent rows equal the sum of their children.

    Uses positional grouping: children are rows between consecutive parent rows.
    Returns (confirmed, confidence).
    """
    if len(sorted_levels) < 2:
        return False, 0.0

    parent_level = sorted_levels[-2]
    child_level = sorted_levels[-1]

    numeric_cols = [c for c in df.columns
                    if pd.api.types.is_numeric_dtype(df[c]) and c != level_col]
    test_cols = numeric_cols[:5]
    if not test_cols:
        return False, 0.0

    level_vals = df[level_col].values
    checks_passed = 0
    checks_total = 0

    for pos in range(len(df)):
        if level_vals[pos] != parent_level:
            continue
        children_pos = []
        for j in range(pos + 1, len(df)):
            if level_vals[j] == child_level:
                children_pos.append(j)
            elif level_vals[j] == parent_level or (
                    j < len(level_vals) and level_vals[j] < parent_level):
                break
        if len(children_pos) < 2:
            continue
        parent_row = df.iloc[pos]
        child_df = df.iloc[children_pos]
        for col in test_cols:
            pv = parent_row[col]
            if pd.isna(pv) or pv == 0:
                continue
            cs = child_df[col].sum()
            checks_total += 1
            if abs(cs - pv) / abs(pv) < 0.05:
                checks_passed += 1
        if checks_total >= 15:
            break

    if checks_total == 0:
        return False, 0.0
    pass_rate = checks_passed / checks_total
    confirmed = pass_rate > 0.7
    confidence = min(1.0, pass_rate + 0.1) if confirmed else max(0.3, pass_rate)
    if checks_total < 5:
        confidence = min(confidence, 0.6)
    return confirmed, round(confidence, 2)


def detect_mixed_admin_levels(df: pd.DataFrame) -> dict | None:
    """Detect rows at multiple admin levels with inline aggregations.

    Returns None if not detected, or a dict with level_col, levels,
    aggregation_confirmed, and confidence.
    """
    level_col = _find_admin_level_col(df)
    if level_col is None:
        return None

    try:
        levels = sorted(df[level_col].dropna().unique(), key=lambda x: int(x))
    except (ValueError, TypeError):
        levels = sorted(df[level_col].dropna().unique(), key=str)

    if len(levels) <= 1:
        return None

    level_counts = {str(lvl): int((df[level_col] == lvl).sum()) for lvl in levels}
    agg_confirmed, agg_confidence = _check_aggregation_sums(df, level_col, levels)

    if not agg_confirmed:
        confidence = agg_confidence if agg_confidence > 0 else 0.5
    else:
        confidence = agg_confidence

    return {
        "level_col": level_col,
        "levels": level_counts,
        "aggregation_confirmed": agg_confirmed,
        "confidence": confidence,
    }


WIDE_FILE_THRESHOLD = 50


def _summarize_column_pattern(columns: list) -> str | None:
    """Detect repeating prefix patterns in column names."""
    str_cols = [str(c) for c in columns]
    prefixes = []
    for c in str_cols:
        parts = re.split(r'[_\s]', c, maxsplit=1)
        if parts:
            prefixes.append(parts[0])
    counts = Counter(prefixes)
    repeated = [(p, n) for p, n in counts.most_common() if n >= 3]
    if not repeated:
        return None
    desc = ", ".join(f"'{p}' x{n}" for p, n in repeated[:10])
    return f"Column name prefixes (repeating): {desc}"


def get_upload_summary(df: pd.DataFrame) -> str:
    """Build a text summary of a DataFrame for the LLM to read."""
    wide = df.shape[1] > WIDE_FILE_THRESHOLD

    if wide:
        cols = list(df.columns)
        shown = cols[:20] + ["..."] + cols[-10:]
        col_line = f"Columns ({df.shape[1]} total, showing first 20 + last 10): {shown}"
        pattern_line = _summarize_column_pattern(cols)
        dtype_counts = Counter(str(dt) for dt in df.dtypes)
        dtype_line = "Dtypes: " + ", ".join(f"{dt}: {n} cols" for dt, n in dtype_counts.most_common())
        sample_line = f"\nFirst 3 rows (first 20 columns):\n{df.head(3).iloc[:, :20].to_string()}"
        null_counts = df.isnull().sum()
        null_groups = Counter(int(v) for v in null_counts)
        null_line = "Null counts: " + ", ".join(
            f"{n_nulls} nulls in {n_cols} col(s)" for n_nulls, n_cols in sorted(null_groups.items())
        )
        lines = [
            f"Shape: {df.shape[0]} rows x {df.shape[1]} columns",
            col_line,
        ]
        if pattern_line:
            lines.append(pattern_line)
        lines += [dtype_line, sample_line, f"\n{null_line}"]
    else:
        lines = [
            f"Shape: {df.shape[0]} rows x {df.shape[1]} columns",
            f"Columns: {list(df.columns)}",
            f"Dtypes:\n{df.dtypes.to_string()}",
            f"\nFirst 3 rows:\n{df.head(3).to_string()}",
            f"\nNull counts:\n{df.isnull().sum().to_string()}",
        ]

    if 'year' in [c.lower() for c in df.columns]:
        year_col = [c for c in df.columns if c.lower() == 'year'][0]
        lines.append(f"\nYear range: {df[year_col].min()} - {df[year_col].max()}")
    return "\n".join(lines)
