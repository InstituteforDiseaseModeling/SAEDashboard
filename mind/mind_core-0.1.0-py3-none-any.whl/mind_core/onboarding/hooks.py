import re

from mind_core.constants import FINALIZE_SUCCESS_SENTINEL
from mind_core.onboarding.config import OnboardingConfig
from mind_core.session import Session
from mind_core.types import ToolResult

_INDICATOR_ID_RE = re.compile(r"META:INDICATOR_ID=(\S+)")


def make_onboarding_post_tool_hook(ob_config: OnboardingConfig, on_finalize=None):
    """Create a hook that records finalized indicators.

    Does NOT call end_onboarding immediately — the agent loop applies the
    transition when the turn ends so the LLM can finalize multiple countries
    in a single turn.
    """
    def hook(tool_name: str, result: ToolResult, tool_input: dict, session: Session):
        if tool_name in ("finalize_indicator", "batch_finalize_indicator"):
            if FINALIZE_SUCCESS_SENTINEL in result.output:
                indicator_id = tool_input.get("name", session.session_id)
                id_match = _INDICATOR_ID_RE.search(result.output)
                if id_match:
                    indicator_id = id_match.group(1)
                ids = session.context.setdefault("_finalized_indicators", [])
                ids.append(indicator_id)
                if on_finalize:
                    on_finalize(session, indicator_id)
    return hook


def make_onboarding_request_hook(ob_config: OnboardingConfig):
    """Create a hook that captures user_instructions from the first chat request."""
    def hook(data: dict, session: Session):
        user_instructions = data.get("user_instructions")
        ctx = session.context.get("onboarding")
        if user_instructions and ctx and not ctx.get("user_instructions"):
            ctx["user_instructions"] = user_instructions
    return hook
