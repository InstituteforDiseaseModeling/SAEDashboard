import subprocess
from pathlib import Path

from mind_core.types import ToolResult

DEFAULT_ALLOWED_CMDS = {"ls", "find", "grep", "head", "tail", "cat", "wc", "sort", "uniq", "cut", "echo", "awk", "sed"}

MAX_OUTPUT = 8000

BASH_CMD_SCHEMA = {
    "type": "function",
    "function": {
        "name": "bash_cmd",
        "description": "Run read-only bash commands for file exploration: ls, find, grep, head, tail, cat, wc, sort, uniq, cut",
        "parameters": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "The bash command to run"}
            },
            "required": ["command"],
        },
    },
}

HEADER_REWRITE_CMDS = {"cat", "tail", "sed", "awk", "head"}


def _is_data_file(path: str, data_extensions: set[str]) -> bool:
    return Path(path.rstrip()).suffix.lower() in data_extensions


def _enforce_header_only(parts: list[str], base: str, data_extensions: set[str]) -> str | None:
    targets = [p for p in parts[1:] if not p.startswith("-") and _is_data_file(p, data_extensions)]
    if not targets:
        return None
    if base in HEADER_REWRITE_CMDS:
        return f"head -1 {' '.join(targets)}"
    return None


def _check_allowed_roots(parts: list[str], cwd: Path, allowed_roots: list[Path]) -> str | None:
    for arg in parts[1:]:
        if arg.startswith("-"):
            continue
        resolved = (cwd / arg).resolve()
        if not any(resolved == root or resolved.is_relative_to(root) for root in allowed_roots):
            return f"Error: path '{arg}' is outside allowed directories"
    return None


def safe_bash(command: str, *, cwd: Path | str,
              allowed_cmds: set[str] | None = None,
              allowed_roots: list[Path] | None = None,
              data_extensions: set[str] | None = None,
              timeout: int = 30) -> ToolResult:
    cwd = Path(cwd).resolve()
    allowed = allowed_cmds if allowed_cmds is not None else DEFAULT_ALLOWED_CMDS

    parts = command.strip().split()
    if not parts:
        return ToolResult(output="Error: empty command")

    base = Path(parts[0]).name
    if base not in allowed:
        return ToolResult(output=f"Error: '{base}' not allowed. Allowed: {', '.join(sorted(allowed))}")

    if allowed_roots:
        err = _check_allowed_roots(parts, cwd, allowed_roots)
        if err:
            return ToolResult(output=err)

    run_cmd = command
    if data_extensions and base in HEADER_REWRITE_CMDS:
        rewritten = _enforce_header_only(parts, base, data_extensions)
        if rewritten:
            run_cmd = rewritten

    try:
        result = subprocess.run(
            run_cmd, shell=True, capture_output=True, text=True,
            timeout=timeout, cwd=cwd,
        )
        out = result.stdout
        if result.returncode != 0:
            out += result.stderr[:500]
    except subprocess.TimeoutExpired:
        return ToolResult(output="Error: command timed out")

    return ToolResult(output=out[:MAX_OUTPUT])
