import re
import subprocess
import sys
import time
from pathlib import Path

from mind_core.constants import FILE_SAVED_PREFIX, METADATA_PREFIXES
from mind_core.types import ToolResult

EXECUTE_PYTHON_SCHEMA = {
    "type": "function",
    "function": {
        "name": "execute_python",
        "description": (
            "Execute Python for data analysis and visualization. "
            "pandas, matplotlib (Agg auto-set), numpy, tabulate available. "
            "Working dir is project root. Print FILE_SAVED:/path for each output file."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "Python code to execute"},
                "description": {"type": "string", "description": "Brief description of what this code does"},
            },
            "required": ["code", "description"],
        },
    },
}


def _sanitize_python_output(out: str) -> str:
    lines = out.splitlines()
    kept = []
    for line in lines:
        if any(line.startswith(p) for p in METADATA_PREFIXES):
            kept.append(line)
        elif line.strip() == "":
            continue
        else:
            kept.append("META:[output hidden — save to file for user display]")
            break
    return "\n".join(kept)


def execute_python(code: str, session_id: str, data_dir: str = "/data",
                   cwd: str | None = None, inherit_env: bool = False,
                   description: str | None = None,
                   timeout: int = 120) -> ToolResult:  # [MIND-CORE-IMPROVEMENT]
    tmpdir = Path(data_dir) / "tmp" / session_id
    tmpdir.mkdir(parents=True, exist_ok=True)

    setup = "try:\n import matplotlib\n matplotlib.use('Agg')\nexcept ImportError:\n pass\nimport warnings\nwarnings.filterwarnings('ignore')\n"
    auto_save = f"""
try:
    import matplotlib.pyplot as __plt, time as __t
    for __n in list(__plt.get_fignums()):
        __f = __plt.figure(__n)
        __p = f'{tmpdir}/autoplot_{{int(__t.time()*1000)}}_{{__n}}.png'
        __f.savefig(__p, dpi=150, bbox_inches='tight')
        print(f'{FILE_SAVED_PREFIX}{{__p}}')
        __plt.close(__f)
except Exception:
    pass
"""
    full_code = setup + code + "\n" + auto_save
    ts = int(time.time() * 1000)
    if description:
        slug = re.sub(r"[^a-z0-9]+", "_", description.lower()).strip("_")[:40]
        script_name = f"script_{slug}_{ts}.py"
    else:
        script_name = f"script_{ts}.py"
    script_path = tmpdir / script_name
    script_path.write_text(full_code)

    env = None if inherit_env else {
        "PATH": "/usr/local/bin:/usr/bin:/bin",
        "HOME": str(tmpdir),
        "MPLCONFIGDIR": str(tmpdir),
    }

    try:
        result = subprocess.run(
            [sys.executable, str(script_path)],
            capture_output=True, text=True, timeout=timeout,  # [MIND-CORE-IMPROVEMENT]
            cwd=cwd or data_dir, env=env,
        )
        out = result.stdout
        if result.returncode != 0:
            out += f"\nERROR: {result.stderr[:1500]}"
    except subprocess.TimeoutExpired:
        return ToolResult(output="Error: code timed out")

    files = re.findall(FILE_SAVED_PREFIX + r"(.+)", out)
    clean = _sanitize_python_output(out)
    clean = re.sub(FILE_SAVED_PREFIX + r".+\n?", "", clean).strip()
    file_list = [f"{session_id}/{Path(f.strip()).name}" for f in files]
    script_note = f"Script saved: {script_path}"
    clean = "\n".join(filter(None, [clean, script_note])).strip()

    return ToolResult(output=clean, files=file_list)
