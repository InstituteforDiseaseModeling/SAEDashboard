from pathlib import Path

from mind_core.tools.bash_cmd import BASH_CMD_SCHEMA, safe_bash
from mind_core.tools.python_exec import EXECUTE_PYTHON_SCHEMA, execute_python


def make_tool_dispatch(cwd: str | Path, data_dir: str | Path,
                       data_extensions: set[str] | None = None,
                       inherit_env: bool = False,
                       python_timeout: int = 120,  # [MIND-CORE-IMPROVEMENT]
                       bash_timeout: int = 30,  # [MIND-CORE-IMPROVEMENT]
                       allowed_commands: set[str] | None = None,  # [MIND-CORE-IMPROVEMENT]
                       ) -> dict:
    cwd_str = str(cwd)

    def _bash(inp, s):
        return safe_bash(inp["command"], cwd=cwd_str, data_extensions=data_extensions,
                         allowed_cmds=allowed_commands, timeout=bash_timeout)  # [MIND-CORE-IMPROVEMENT]

    def _python(inp, s):
        return execute_python(inp["code"], s.session_id, data_dir=str(data_dir),
                              cwd=cwd_str, inherit_env=inherit_env,
                              description=inp.get("description"),
                              timeout=python_timeout)  # [MIND-CORE-IMPROVEMENT]

    return {"bash_cmd": _bash, "execute_python": _python}


def default_progress_message(tool_name: str, tool_input: dict) -> str:
    if tool_name == "bash_cmd":
        cmd = tool_input.get("command", "")
        if "grep" in cmd:
            return "Searching files..."
        if any(k in cmd for k in ("cat", "head", "tail")):
            return "Reading file..."
        if any(k in cmd for k in ("ls", "find")):
            return "Exploring project structure..."
        return f"Running: {cmd[:60]}"
    if tool_name == "execute_python":
        return tool_input.get("description", "Running analysis...")[:80]
    return f"Using {tool_name}..."
