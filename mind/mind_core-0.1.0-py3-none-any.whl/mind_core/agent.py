import json
import logging
import re
from pathlib import Path

import litellm

from mind_core.config import MindConfig, _resolve
from mind_core.session import Session
from mind_core.tools import default_progress_message
from mind_core.truncation import truncate_messages
from mind_core.types import ToolResult

logger = logging.getLogger(__name__)


def _repair_session(messages: list) -> list:
    while messages and messages[-1]["role"] == "assistant":
        if messages[-1].get("tool_calls"):
            messages.pop()
        else:
            break
    return messages


def _default_progress_msg(tool_name: str, tool_input: dict) -> str:
    return default_progress_message(tool_name, tool_input)


def _default_title(message: str) -> str:
    text = message.strip()[:200]
    words = text.split()
    filler = {"the", "a", "an", "is", "are", "of", "for", "in", "on", "to", "and", "or",
              "can", "you", "me", "my", "this", "that", "it", "what", "how", "do", "does",
              "please", "i", "about", "with"}
    key_words = [w.strip("?,.'\"!") for w in words if w.lower().strip("?,.'\"!") not in filler]
    snippet = " ".join(key_words[:5]) if key_words else " ".join(words[:5])
    return snippet[:60] if snippet else "New conversation"


class _StreamResult:
    __slots__ = ("finish_reason", "content", "tool_calls", "sse_events")

    def __init__(self):
        self.finish_reason = None
        self.content = ""
        self.tool_calls = None
        self.sse_events = []


def _collect_stream(stream, sse_fn):
    result = _StreamResult()
    content_parts = []
    tool_calls_acc = {}

    for chunk in stream:
        delta = chunk.choices[0].delta if chunk.choices else None
        if delta is None:
            continue
        if chunk.choices[0].finish_reason:
            result.finish_reason = chunk.choices[0].finish_reason
        if delta.content:
            content_parts.append(delta.content)
            result.sse_events.append(sse_fn({"type": "text_delta", "text": delta.content}))
        if delta.tool_calls:
            for tc_delta in delta.tool_calls:
                idx = tc_delta.index
                if idx not in tool_calls_acc:
                    tool_calls_acc[idx] = {"id": "", "name": "", "arguments": ""}
                if tc_delta.id:
                    tool_calls_acc[idx]["id"] = tc_delta.id
                if tc_delta.function:
                    if tc_delta.function.name:
                        tool_calls_acc[idx]["name"] = tc_delta.function.name
                    if tc_delta.function.arguments:
                        tool_calls_acc[idx]["arguments"] += tc_delta.function.arguments

    result.content = "".join(content_parts)
    if tool_calls_acc:
        result.tool_calls = [
            {"id": tool_calls_acc[i]["id"], "type": "function",
             "function": {"name": tool_calls_acc[i]["name"], "arguments": tool_calls_acc[i]["arguments"]}}
            for i in sorted(tool_calls_acc)
        ]
    return result


def run_agent_stream(config: MindConfig, session: Session, user_message: str,
                     api_key: str | None = None):
    """Main agent loop. Yields SSE events as the LLM thinks and calls tools."""
    def sse(event: dict) -> str:
        return f"data: {json.dumps(event)}\n\n"

    try:
        if user_message.strip() == "/clear":
            session.messages = []
            config.session_store.save(session)
            yield sse({"type": "response", "text": "Session cleared.", "files": [],
                        "mode": session.mode, "session_id": session.session_id})
            return

        if config.pre_message_hook:
            refusal = config.pre_message_hook(user_message, session)
            if refusal is not None:
                yield sse({"type": "response", "text": refusal, "files": [],
                            "mode": session.mode, "session_id": session.session_id})
                return

        _repair_session(session.messages)
        session.messages.append({"role": "user", "content": user_message})

        if not session.title and user_message.strip():
            if config.title_generator:
                session.title = config.title_generator(user_message, session)
            else:
                session.title = _default_title(user_message)

        generated_files: list[str] = []
        tools_used: list[dict] = []
        generated_scripts: list[str] = []
        doc_sources_before = len(session.context.get("doc_sources", []))
        initial_mode = session.mode
        progress = 5
        model = config.model
        current_mode = session.mode

        system_prompt = _resolve(config.system_prompt, session)
        if config.system_prompt_suffix:
            if isinstance(system_prompt, str):
                system_prompt += "\n" + config.system_prompt_suffix
            elif isinstance(system_prompt, list):
                system_prompt = system_prompt + [{"type": "text", "text": config.system_prompt_suffix}]

        tools = _resolve(config.tool_schemas, session)

        yield sse({"type": "progress", "progress": progress, "message": "Thinking...", "model": model})

        context_pct = 0
        for _ in range(config.max_iterations):
            truncated, context_info = truncate_messages(
                session.messages, model=model,
                model_budgets=config.model_budgets, default_budget=config.default_budget,
            )
            context_pct = context_info["pct"]
            api_messages = [{"role": "system", "content": system_prompt}] + truncated

            completion_kwargs = dict(model=model, max_tokens=config.max_tokens,
                                     messages=api_messages, tools=tools or None, stream=True)
            if config.api_base:
                completion_kwargs["base_url"] = config.api_base
            effective_key = config.api_key or api_key
            if effective_key:
                completion_kwargs["api_key"] = effective_key

            stream = litellm.completion(**completion_kwargs)
            logger.info("litellm stream request=%s", model)
            sr = _collect_stream(stream, sse)
            for ev in sr.sse_events:
                yield ev
            content = sr.content or None
            finish_reason = sr.finish_reason
            assistant_msg = {"role": "assistant", "content": content, "model": model}
            if sr.tool_calls:
                assistant_msg["tool_calls"] = sr.tool_calls

            session.messages.append(assistant_msg)
            session.current_model = model

            if finish_reason == "stop":
                turn_doc_sources = session.context.get("doc_sources", [])[doc_sources_before:]
                resources = {
                    "tools_used": tools_used,
                    "scripts": generated_scripts,
                    "files": list(dict.fromkeys(generated_files)),
                    "doc_sources": turn_doc_sources,
                }
                if generated_files:
                    assistant_msg["files"] = list(dict.fromkeys(generated_files))
                assistant_msg["resources"] = resources
                text = content
                form_data = None
                form_match = re.search(r'<form>(.*?)</form>', text, re.DOTALL)
                if form_match:
                    raw_json = form_match.group(1).strip()
                    try:
                        form_data = json.loads(raw_json)
                        text = re.sub(r'<form>.*?</form>', '', text, flags=re.DOTALL).strip()
                    except json.JSONDecodeError as exc:
                        logger.warning("Form JSON parse failed: %s", exc)
                        text = re.sub(r'<form>.*?</form>', '', text, flags=re.DOTALL).strip()
                        text += "\n\n(The form didn't load correctly. Please describe your preferences in text instead.)"
                finalized = session.context.pop("_finalized_indicators", None)
                if finalized and session.mode == "onboarding":
                    from mind_core.onboarding.session_helpers import end_onboarding
                    end_onboarding(session, finalized[-1])
                config.session_store.save(session)
                yield sse({
                    "type": "response", "text": text,
                    "files": list(dict.fromkeys(generated_files)),
                    "form": form_data,
                    "indicator_created": session.mode != initial_mode,
                    "mode": session.mode, "session_id": session.session_id,
                    "model": model, "context_pct": context_pct,
                    "resources": resources,
                })
                break

            if finish_reason != "tool_calls":
                logger.warning("Unexpected finish_reason: %s", finish_reason)
                yield sse({"type": "error", "message": "Something went wrong while processing your request. Please try again."})
                break

            tool_results = []
            dispatch = _resolve(config.tool_dispatch, session)
            for tc_dict in assistant_msg.get("tool_calls", []):
                tool_name = tc_dict["function"]["name"]
                try:
                    tool_input = json.loads(tc_dict["function"]["arguments"])
                except (json.JSONDecodeError, KeyError) as e:
                    tool_results.append({"role": "tool", "tool_call_id": tc_dict["id"],
                                         "content": f"ERROR: Invalid arguments: {e}"})
                    continue

                progress = min(progress + 15, 85)
                if config.progress_message:
                    msg = config.progress_message(tool_name, tool_input)
                else:
                    msg = _default_progress_msg(tool_name, tool_input)
                yield sse({"type": "progress", "progress": progress, "message": msg})

                if tool_name in dispatch:
                    tools_used.append({"name": tool_name, "description": msg})
                try:
                    if tool_name in dispatch:
                        result = dispatch[tool_name](tool_input, session)
                        generated_files.extend(result.files)
                        if tool_name == "execute_python":
                            script_match = re.search(r"Script saved:\s*(.+)", result.output)
                            if script_match:
                                script_rel = f"{session.session_id}/{Path(script_match.group(1).strip()).name}"
                                generated_scripts.append(script_rel)
                        result_text = result.output
                        file_notes = "\n".join(f"Saved: {config.file_saved_prefix}/{f}" for f in result.files) if result.files else ""
                        result_text = "\n".join(filter(None, [result_text, file_notes])).strip()
                    else:
                        result_text = f"Unknown tool: {tool_name}"
                        result = ToolResult(output=result_text)
                except Exception as e:
                    logger.warning("Tool %s failed: %s", tool_name, e, exc_info=True)
                    result_text = f"ERROR: Tool '{tool_name}' failed: {type(e).__name__}: {e}"
                    result = ToolResult(output=result_text)

                if config.post_tool_hook:
                    config.post_tool_hook(tool_name, result, tool_input, session)

                if session.mode != current_mode:
                    yield sse({"type": "mode_change", "mode": session.mode})
                    current_mode = session.mode
                    tools = _resolve(config.tool_schemas, session)
                    system_prompt = _resolve(config.system_prompt, session)
                    if config.system_prompt_suffix:
                        if isinstance(system_prompt, str):
                            system_prompt += "\n" + config.system_prompt_suffix
                        elif isinstance(system_prompt, list):
                            system_prompt = system_prompt + [{"type": "text", "text": config.system_prompt_suffix}]

                tool_results.append({
                    "role": "tool",
                    "tool_call_id": tc_dict["id"],
                    "content": result_text,
                })

            session.messages.extend(tool_results)
        else:
            turn_doc_sources = session.context.get("doc_sources", [])[doc_sources_before:]
            yield sse({
                "type": "response",
                "text": "This request required too many steps to complete. If you want me to proceed please type 'continue' in the chat.",
                "files": list(dict.fromkeys(generated_files)),
                "form": None,
                "indicator_created": session.mode != initial_mode,
                "mode": session.mode, "session_id": session.session_id,
                "model": model, "context_pct": context_pct,
                "resources": {
                    "tools_used": tools_used, "scripts": generated_scripts,
                    "files": list(dict.fromkeys(generated_files)),
                    "doc_sources": turn_doc_sources,
                },
            })

        config.session_store.save(session)

    except litellm.AuthenticationError:
        yield sse({"type": "error", "message": "The API key is invalid or expired. Please check your key and try again."})
    except litellm.RateLimitError:
        yield sse({"type": "error", "message": "The AI service is currently busy. Please wait a moment and try again."})
    except (litellm.APIConnectionError, litellm.Timeout):
        yield sse({"type": "error", "message": "Could not reach the AI service. Please check your connection and try again."})
    except Exception as e:
        logger.exception("Agent loop error")
        yield sse({"type": "error", "message": "An unexpected error occurred. Please try again, or contact support if the problem persists."})
    finally:
        if session.messages:
            config.session_store.save(session)
