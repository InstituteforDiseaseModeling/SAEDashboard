import json
import logging

import litellm

logger = logging.getLogger(__name__)

DEFAULT_BUDGET = 80_000
KEEP_LAST_TURNS = 2
COMPRESS_AFTER_TURNS = 3
MAX_TOOL_RESULT_CHARS = 500

MODEL_BUDGETS = {
    "claude-opus-4-6": 180_000,
    "claude-sonnet-4-6": 180_000,
    "claude-haiku-4-5-20251001": 180_000,
}


def _estimate_tokens(messages: list[dict], model: str | None = None) -> int:
    if model:
        try:
            return litellm.token_counter(model=model, messages=messages)
        except Exception:
            pass
    return sum(len(json.dumps(m)) for m in messages) // 4


def _get_budget(model: str | None, model_budgets: dict | None = None,
                default_budget: int = DEFAULT_BUDGET) -> int:
    budgets = model_budgets if model_budgets is not None else MODEL_BUDGETS
    if model and model in budgets:
        return budgets[model]
    return default_budget


def _split_turns(messages: list[dict]) -> list[list[dict]]:
    turns: list[list[dict]] = []
    current: list[dict] = []
    for msg in messages:
        if msg["role"] == "user" and current:
            turns.append(current)
            current = []
        current.append(msg)
    if current:
        turns.append(current)
    return turns


def _compress_tool_result(content: str) -> str:
    first_line = content.split("\n", 1)[0][:MAX_TOOL_RESULT_CHARS]
    return f"[Truncated. Result: {first_line}]"


def truncate_messages(
    messages: list[dict], model: str | None = None, budget: int | None = None,
    model_budgets: dict | None = None, default_budget: int = DEFAULT_BUDGET,
) -> tuple[list[dict], dict]:
    effective_budget = budget if budget is not None else _get_budget(model, model_budgets, default_budget)
    token_count = _estimate_tokens(messages, model)

    if token_count <= effective_budget:
        return messages, {"token_count": token_count, "budget": effective_budget, "pct": round(token_count * 100 / effective_budget)}

    turns = _split_turns(messages)
    if len(turns) <= KEEP_LAST_TURNS + 1:
        return messages, {"token_count": token_count, "budget": effective_budget, "pct": round(token_count * 100 / effective_budget)}

    keep_first = turns[0]
    keep_last = turns[-KEEP_LAST_TURNS:]
    middle = turns[1:-KEEP_LAST_TURNS]

    for i, turn in enumerate(middle):
        if i >= len(middle) - COMPRESS_AFTER_TURNS:
            continue
        for j, msg in enumerate(turn):
            if msg["role"] == "tool" and len(msg.get("content", "")) > MAX_TOOL_RESULT_CHARS:
                turn[j] = {**msg, "content": _compress_tool_result(msg["content"])}

    result = keep_first
    for turn in middle:
        result = result + turn
    for turn in keep_last:
        result = result + turn

    if _estimate_tokens(result, model) <= effective_budget:
        final_count = _estimate_tokens(result, model)
        return result, {"token_count": final_count, "budget": effective_budget, "pct": round(final_count * 100 / effective_budget)}

    while middle and _estimate_tokens(result, model) > effective_budget:
        middle.pop(0)
        result = keep_first
        for turn in middle:
            result = result + turn
        for turn in keep_last:
            result = result + turn

    final_count = _estimate_tokens(result, model)
    return result, {"token_count": final_count, "budget": effective_budget, "pct": round(final_count * 100 / effective_budget)}
