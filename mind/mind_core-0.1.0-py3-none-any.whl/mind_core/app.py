from __future__ import annotations

from typing import TYPE_CHECKING

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from mind_core.config import MindConfig
from mind_core.routes import create_chat_router, create_files_router, create_sessions_router

if TYPE_CHECKING:
    from mind_core.onboarding.config import OnboardingConfig


def create_app(
    config: MindConfig,
    ob_config: "OnboardingConfig | None" = None,
    *,
    chat: bool = True,
    sessions: bool = True,
    uploads: bool = False,
    onboarding: bool | None = None,
    indicators: bool | None = None,
    **fastapi_kwargs,
) -> FastAPI:
    """Build a FastAPI app with routes based on config flags."""
    app = FastAPI(**fastapi_kwargs)
    app.state.mind_config = config

    app.add_middleware(  # [MIND-CORE-IMPROVEMENT] configurable CORS origins
        CORSMiddleware,
        allow_origins=config.cors_origins,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    if chat:
        app.include_router(create_chat_router(config))
        app.include_router(create_files_router(config))
    if sessions:
        app.include_router(create_sessions_router(config))

    _onboarding = onboarding if onboarding is not None else (ob_config is not None)
    _indicators = indicators if indicators is not None else (ob_config is not None)

    if ob_config is not None and (_onboarding or _indicators):
        from mind_core.onboarding.routes import create_onboarding_upload_router, create_indicators_router
        if _onboarding:
            app.include_router(create_onboarding_upload_router(config, ob_config))
        if _indicators:
            app.include_router(create_indicators_router(config, ob_config))

    @app.get("/")
    async def health():
        return {"status": "ok"}

    return app
